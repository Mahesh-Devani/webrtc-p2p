#!/usr/bin/env python3
"""
P2P Connect — Zero-Dependency Native OS Remote Desktop Bridge (Python)
======================================================================
High performance input injection bridge for P2P Connect Remote Desktop.
Requires ZERO external pip packages! Built entirely on Python 3 standard
library (asyncio, struct, hashlib, base64, ctypes) with Quartz (macOS)
and Win32 (Windows) acceleration.

Features:
  - Standard RFC 6455 WebSocket server via asyncio.start_server
  - Strict Cross-Site WebSocket Hijacking (CSWSH) Origin filtering
  - Cryptographic token authentication (~/.p2p-connect-token)
  - Emergency Panic Failsafe (slam mouse into screen corner to abort)
  - Sub-millisecond CoreGraphics Quartz mouse & keyboard event injection
  - Full Unicode text typing (emojis, uppercase, international characters)
  - Non-blocking freshest-coordinate cursor smoothing loop
"""

import sys
import os
import time
import datetime
import builtins
import atexit
import json
import asyncio
import argparse
import secrets
import base64
import hashlib
import struct
import urllib.parse
import re
import ssl
import ctypes
import ctypes.util
import subprocess
import threading
import zlib

# ── Timestamped Logging Wrapper ───────────────────────────────────────────────
_builtin_print = builtins.print

def timestamped_print(*args, **kwargs):
    if 'flush' not in kwargs:
        kwargs['flush'] = True
    dest_file = kwargs.get('file', None)
    if dest_file is None or dest_file in (sys.stdout, sys.stderr):
        now_str = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        if args and isinstance(args[0], str) and (args[0].startswith('=') or args[0].startswith('  ')):
            _builtin_print(*args, **kwargs)
        elif args:
            _builtin_print(f'[{now_str}]', *args, **kwargs)
        else:
            _builtin_print(*args, **kwargs)
    else:
        _builtin_print(*args, **kwargs)

builtins.print = timestamped_print

# ── 1. Native OS Input Injection Engine (Zero-Dependency) ────────────────────
SCREEN_WIDTH = 1920
SCREEN_HEIGHT = 1080

PLATFORM = sys.platform

if PLATFORM == 'darwin':
    cg = ctypes.cdll.LoadLibrary(ctypes.util.find_library('CoreGraphics'))

    class CGPoint(ctypes.Structure):
        _fields_ = [("x", ctypes.c_double), ("y", ctypes.c_double)]

    class CGSize(ctypes.Structure):
        _fields_ = [("width", ctypes.c_double), ("height", ctypes.c_double)]

    class CGRect(ctypes.Structure):
        _fields_ = [("origin", CGPoint), ("size", CGSize)]

    main_display = cg.CGMainDisplayID()
    cg.CGDisplayBounds.argtypes = [ctypes.c_uint32]
    cg.CGDisplayBounds.restype = CGRect

    cg.CGEventCreateMouseEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint32, CGPoint, ctypes.c_uint32]
    cg.CGEventCreateMouseEvent.restype = ctypes.c_void_p

    cg.CGEventPost.argtypes = [ctypes.c_uint32, ctypes.c_void_p]
    cg.CGEventPost.restype = None

    if hasattr(cg, 'CGEventPostToPid'):
        cg.CGEventPostToPid.argtypes = [ctypes.c_int32, ctypes.c_void_p]
        cg.CGEventPostToPid.restype = None

    def _post_cg_event(evt, target_pid=None):
        if not evt:
            return
        if target_pid and int(target_pid) > 0 and hasattr(cg, 'CGEventPostToPid'):
            try:
                cg.CGEventPostToPid(int(target_pid), evt)
            except Exception:
                pass
        cg.CGEventPost(kCGHIDEventTap, evt)

    cg.CGEventCreateKeyboardEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint16, ctypes.c_bool]
    cg.CGEventCreateKeyboardEvent.restype = ctypes.c_void_p

    cg.CGEventKeyboardSetUnicodeString.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_wchar_p]
    cg.CGEventKeyboardSetUnicodeString.restype = None

    cg.CGEventSetFlags.argtypes = [ctypes.c_void_p, ctypes.c_uint64]
    cg.CGEventSetFlags.restype = None

    cg.CGEventCreateScrollWheelEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_int32]
    cg.CGEventCreateScrollWheelEvent.restype = ctypes.c_void_p

    cg.CGEventSetIntegerValueField.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int64]
    cg.CGEventSetIntegerValueField.restype = None

    cg.CFRelease.argtypes = [ctypes.c_void_p]
    cg.CFRelease.restype = None

    # CoreGraphics Hardware Event Source & Display Sleep APIs
    kCGEventSourceStateHIDSystemState = 1
    cg.CGEventSourceCreate.argtypes = [ctypes.c_int32]
    cg.CGEventSourceCreate.restype = ctypes.c_void_p
    cg.CGDisplayIsAsleep.argtypes = [ctypes.c_uint32]
    cg.CGDisplayIsAsleep.restype = ctypes.c_bool
    cg.CGRestorePermanentDisplayConfiguration.argtypes = []
    cg.CGRestorePermanentDisplayConfiguration.restype = None

    # Pre-allocate shared hardware HID event source to ensure all synthetic inputs
    # are recognized by WindowServer as real hardware HID activity (waking display/lock screen)
    _hid_event_source = cg.CGEventSourceCreate(kCGEventSourceStateHIDSystemState)

    # macOS Display Reconfiguration Callback
    CGDisplayReconfigurationCallBack = ctypes.CFUNCTYPE(None, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p)
    cg.CGDisplayRegisterReconfigurationCallback.argtypes = [CGDisplayReconfigurationCallBack, ctypes.c_void_p]
    cg.CGDisplayRegisterReconfigurationCallback.restype = ctypes.c_int32
    cg.CGDisplayRemoveReconfigurationCallback.argtypes = [CGDisplayReconfigurationCallBack, ctypes.c_void_p]
    cg.CGDisplayRemoveReconfigurationCallback.restype = ctypes.c_int32

    # CGEvent Types
    kCGEventLeftMouseDown = 1
    kCGEventLeftMouseUp = 2
    kCGEventRightMouseDown = 3
    kCGEventRightMouseUp = 4
    kCGEventMouseMoved = 5
    kCGEventLeftMouseDragged = 6
    kCGEventRightMouseDragged = 7
    kCGEventOtherMouseDown = 25
    kCGEventOtherMouseUp = 26
    kCGMouseEventClickState = 1
    kCGHIDEventTap = 0

    # CGEventFlags (modifier masks)
    kCGEventFlagMaskShift = 0x00020000
    kCGEventFlagMaskControl = 0x00040000
    kCGEventFlagMaskAlternate = 0x00080000
    kCGEventFlagMaskCommand = 0x00100000

    # macOS Virtual Keycodes (US Layout)
    VK_MAP = {
        'return': 36, 'enter': 36, 'tab': 48, 'space': 49, ' ': 49,
        'delete': 51, 'backspace': 51, 'escape': 53, 'esc': 53,
        'command': 55, 'cmd': 55, 'win': 55, 'meta': 55,
        'shift': 56, 'capslock': 57, 'alt': 58, 'option': 58, 'control': 59, 'ctrl': 59,
        'rightshift': 60, 'rightoption': 61, 'rightcontrol': 62,
        'left': 123, 'arrowleft': 123, 'right': 124, 'arrowright': 124,
        'down': 125, 'arrowdown': 125, 'up': 126, 'arrowup': 126,
        'f1': 122, 'f2': 120, 'f3': 99, 'f4': 118, 'f5': 96,
        'f6': 97, 'f7': 98, 'f8': 100, 'f9': 101, 'f10': 109, 'f11': 103, 'f12': 111,
        'home': 115, 'pageup': 116, 'end': 119, 'pagedown': 121,
        # Alphabet
        'a': 0, 'b': 11, 'c': 8, 'd': 2, 'e': 14, 'f': 3, 'g': 5, 'h': 4,
        'i': 34, 'j': 38, 'k': 40, 'l': 37, 'm': 46, 'n': 45, 'o': 31, 'p': 35,
        'q': 12, 'r': 15, 's': 1, 't': 17, 'u': 32, 'v': 9, 'w': 13, 'x': 7,
        'y': 16, 'z': 6,
        # Numbers
        '1': 18, '2': 19, '3': 20, '4': 21, '5': 23, '6': 22, '7': 26, '8': 28, '9': 25, '0': 29,
        # Unshifted symbols & punctuation
        '-': 27, '=': 24, '[': 33, ']': 30, '\\': 42, ';': 41, "'": 39, ',': 43, '.': 47, '/': 44, '`': 50
    }

    # Shifted symbols mapping to base virtual keycode
    SHIFT_MAP = {
        '!': 18, '@': 19, '#': 20, '$': 21, '%': 23,
        '^': 22, '&': 26, '*': 28, '(': 25, ')': 29,
        '_': 27, '+': 24, '{': 33, '}': 30, '|': 42,
        ':': 41, '"': 39, '<': 43, '>': 47, '?': 44,
        '~': 50
    }

    _mouse_down_state = {0: False, 1: False, 2: False}

    def native_mouse_move(x, y, target_pid=None):
        pt = CGPoint(float(x), float(y))
        if _mouse_down_state[0]:
            evt_type = kCGEventLeftMouseDragged
        elif _mouse_down_state[2]:
            evt_type = kCGEventRightMouseDragged
        else:
            evt_type = kCGEventMouseMoved
        evt = cg.CGEventCreateMouseEvent(_hid_event_source, evt_type, pt, 0)
        if evt:
            _post_cg_event(evt, target_pid)
            cg.CFRelease(evt)

    def native_mouse_down(btn, x, y, target_pid=None):
        pt = CGPoint(float(x), float(y))
        _mouse_down_state[btn] = True
        if btn == 2:
            evt_type = kCGEventRightMouseDown
        elif btn == 1:
            evt_type = kCGEventOtherMouseDown
        else:
            evt_type = kCGEventLeftMouseDown
        evt = cg.CGEventCreateMouseEvent(_hid_event_source, evt_type, pt, btn)
        if evt:
            _post_cg_event(evt, target_pid)
            cg.CFRelease(evt)

    def native_mouse_up(btn, x, y, target_pid=None):
        pt = CGPoint(float(x), float(y))
        _mouse_down_state[btn] = False
        if btn == 2:
            evt_type = kCGEventRightMouseUp
        elif btn == 1:
            evt_type = kCGEventOtherMouseUp
        else:
            evt_type = kCGEventLeftMouseUp
        evt = cg.CGEventCreateMouseEvent(_hid_event_source, evt_type, pt, btn)
        if evt:
            _post_cg_event(evt, target_pid)
            cg.CFRelease(evt)

    def native_mouse_click(btn, clicks, x, y, target_pid=None):
        pt = CGPoint(float(x), float(y))
        down_type = kCGEventRightMouseDown if btn == 2 else kCGEventLeftMouseDown
        up_type = kCGEventRightMouseUp if btn == 2 else kCGEventLeftMouseUp

        for i in range(1, clicks + 1):
            evt_down = cg.CGEventCreateMouseEvent(_hid_event_source, down_type, pt, btn)
            if evt_down:
                cg.CGEventSetIntegerValueField(evt_down, kCGMouseEventClickState, i)
                _post_cg_event(evt_down, target_pid)
                cg.CFRelease(evt_down)

            evt_up = cg.CGEventCreateMouseEvent(_hid_event_source, up_type, pt, btn)
            if evt_up:
                cg.CGEventSetIntegerValueField(evt_up, kCGMouseEventClickState, i)
                _post_cg_event(evt_up, target_pid)
                cg.CFRelease(evt_up)

    def native_scroll(units, target_pid=None):
        evt = cg.CGEventCreateScrollWheelEvent(_hid_event_source, 0, 1, int(units))
        if evt:
            _post_cg_event(evt, target_pid)
            cg.CFRelease(evt)

    def release_all_modifiers(target_pid=None):
        # Release modifier keycodes: LeftShift (56), RightShift (60), LeftAlt (58), RightAlt (61),
        # LeftCtrl (59), RightCtrl (62), Command (55)
        for code in (56, 60, 58, 61, 59, 62, 55):
            evt = cg.CGEventCreateKeyboardEvent(_hid_event_source, code, False)
            if evt:
                cg.CGEventSetFlags(evt, 0)
                _post_cg_event(evt, target_pid)
                cg.CFRelease(evt)

    def native_key(key, is_down, modifiers=None, target_pid=None):
        mods = modifiers or {}
        shift_pressed = bool(mods.get('shift', False))
        ctrl_pressed = bool(mods.get('ctrl', False))
        alt_pressed = bool(mods.get('alt', False))
        meta_pressed = bool(mods.get('meta', False) or mods.get('command', False) or mods.get('win', False))

        code = None
        needs_shift = False

        # 1. Check if key is a shifted symbol (e.g. '!', '@', '#')
        if key in SHIFT_MAP:
            code = SHIFT_MAP[key]
            needs_shift = True
        # 2. Check if key is an uppercase letter (e.g. 'A' - 'Z')
        elif len(key) == 1 and key.isupper():
            code = VK_MAP.get(key.lower())
            needs_shift = True
        # 3. Check regular VK_MAP (lowercase, numbers, punctuation, control keys)
        elif key.lower() in VK_MAP:
            code = VK_MAP[key.lower()]
        elif key in VK_MAP:
            code = VK_MAP[key]

        if code is not None:
            evt = cg.CGEventCreateKeyboardEvent(_hid_event_source, code, is_down)
            if evt:
                flags = 0
                if shift_pressed or (needs_shift and is_down):
                    flags |= kCGEventFlagMaskShift
                if ctrl_pressed:
                    flags |= kCGEventFlagMaskControl
                if alt_pressed:
                    flags |= kCGEventFlagMaskAlternate
                if meta_pressed:
                    flags |= kCGEventFlagMaskCommand

                # UNCONDITIONALLY set flags to explicitly clear modifiers when flags == 0
                cg.CGEventSetFlags(evt, flags)

                _post_cg_event(evt, target_pid)
                cg.CFRelease(evt)

                # If this was an auto-shifted character (e.g. 'A' or '!') and shift key is NOT physically held down:
                # Post a keyup on shift code (56) with flags=0 so WindowServer immediately clears any latch
                if needs_shift and not shift_pressed and not is_down:
                    clr_evt = cg.CGEventCreateKeyboardEvent(_hid_event_source, 56, False)
                    if clr_evt:
                        cg.CGEventSetFlags(clr_evt, 0)
                        _post_cg_event(clr_evt, target_pid)
                        cg.CFRelease(clr_evt)

        elif len(key) == 1:
            # Fallback for unicode characters outside US layout
            evt = cg.CGEventCreateKeyboardEvent(_hid_event_source, 0, is_down)
            if evt:
                flags = 0
                if shift_pressed or (key.isupper() and is_down):
                    flags |= kCGEventFlagMaskShift
                cg.CGEventSetFlags(evt, flags)
                cg.CGEventKeyboardSetUnicodeString(evt, 1, key)
                _post_cg_event(evt, target_pid)
                cg.CFRelease(evt)

    def native_type_text(text, target_pid=None):
        for char in text:
            native_key(char, True, target_pid=target_pid)
            native_key(char, False, target_pid=target_pid)
        release_all_modifiers(target_pid=target_pid)

elif PLATFORM == 'win32':
    # Native Win32 user32 input driver (Zero external dependencies, pure Python standard library)
    user32 = ctypes.windll.user32

    # Enable process DPI awareness so pixel coordinates match physical display resolution
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # PROCESS_PER_MONITOR_DPI_AWARE
    except Exception:
        try:
            user32.SetProcessDPIAware()
        except Exception:
            pass

    SCREEN_WIDTH = user32.GetSystemMetrics(0)
    SCREEN_HEIGHT = user32.GetSystemMetrics(1)

    MOUSEEVENTF_MOVE = 0x0001
    MOUSEEVENTF_LEFTDOWN = 0x0002
    MOUSEEVENTF_LEFTUP = 0x0004
    MOUSEEVENTF_RIGHTDOWN = 0x0008
    MOUSEEVENTF_RIGHTUP = 0x0010
    MOUSEEVENTF_MIDDLEDOWN = 0x0020
    MOUSEEVENTF_MIDDLEUP = 0x0040
    MOUSEEVENTF_WHEEL = 0x0800

    def native_mouse_move(x, y, target_pid=None):
        user32.SetCursorPos(int(round(x)), int(round(y)))

    def native_mouse_down(btn, x, y, target_pid=None):
        user32.SetCursorPos(int(round(x)), int(round(y)))
        flags = MOUSEEVENTF_RIGHTDOWN if btn == 2 else (MOUSEEVENTF_MIDDLEDOWN if btn == 1 else MOUSEEVENTF_LEFTDOWN)
        user32.mouse_event(flags, 0, 0, 0, 0)

    def native_mouse_up(btn, x, y, target_pid=None):
        user32.SetCursorPos(int(round(x)), int(round(y)))
        flags = MOUSEEVENTF_RIGHTUP if btn == 2 else (MOUSEEVENTF_MIDDLEUP if btn == 1 else MOUSEEVENTF_LEFTUP)
        user32.mouse_event(flags, 0, 0, 0, 0)

    def native_mouse_click(btn, clicks, x, y, target_pid=None):
        user32.SetCursorPos(int(round(x)), int(round(y)))
        down_flag = MOUSEEVENTF_RIGHTDOWN if btn == 2 else (MOUSEEVENTF_MIDDLEDOWN if btn == 1 else MOUSEEVENTF_LEFTDOWN)
        up_flag = MOUSEEVENTF_RIGHTUP if btn == 2 else (MOUSEEVENTF_MIDDLEUP if btn == 1 else MOUSEEVENTF_LEFTUP)
        for _ in range(clicks):
            user32.mouse_event(down_flag, 0, 0, 0, 0)
            user32.mouse_event(up_flag, 0, 0, 0, 0)

    def native_scroll(units, target_pid=None):
        delta = int(units * 120)
        user32.mouse_event(MOUSEEVENTF_WHEEL, 0, 0, delta, 0)

    WIN_VK_MAP = {
        'backspace': 0x08, 'tab': 0x09, 'clear': 0x0C, 'return': 0x0D, 'enter': 0x0D,
        'shift': 0x10, 'ctrl': 0x11, 'control': 0x11, 'alt': 0x12, 'pause': 0x13,
        'capslock': 0x14, 'escape': 0x1B, 'esc': 0x1B, 'space': 0x20, ' ': 0x20,
        'pageup': 0x21, 'pagedown': 0x22, 'end': 0x23, 'home': 0x24,
        'left': 0x25, 'up': 0x26, 'right': 0x27, 'down': 0x28,
        'select': 0x29, 'print': 0x2A, 'execute': 0x2B, 'printscreen': 0x2C, 'prtsc': 0x2C,
        'insert': 0x2D, 'delete': 0x2E, 'help': 0x2F,
        'win': 0x5B, 'windows': 0x5B, 'meta': 0x5B, 'command': 0x5B, 'cmd': 0x5B,
        'numpad0': 0x60, 'numpad1': 0x61, 'numpad2': 0x62, 'numpad3': 0x63, 'numpad4': 0x64,
        'numpad5': 0x65, 'numpad6': 0x66, 'numpad7': 0x67, 'numpad8': 0x68, 'numpad9': 0x69,
        'multiply': 0x6A, 'add': 0x6B, 'separator': 0x6C, 'subtract': 0x6D, 'decimal': 0x6E, 'divide': 0x6F,
        'f1': 0x70, 'f2': 0x71, 'f3': 0x72, 'f4': 0x73, 'f5': 0x74, 'f6': 0x75,
        'f7': 0x76, 'f8': 0x77, 'f9': 0x78, 'f10': 0x79, 'f11': 0x7A, 'f12': 0x7B,
        'numlock': 0x90, 'scrolllock': 0x91,
    }

    KEYEVENTF_EXTENDEDKEY = 0x0001
    KEYEVENTF_KEYUP = 0x0002
    KEYEVENTF_UNICODE = 0x0004

    def native_key(key, is_down, modifiers=None, target_pid=None):
        k_lower = key.lower() if isinstance(key, str) else str(key).lower()
        flags = KEYEVENTF_KEYUP if not is_down else 0
        if k_lower in WIN_VK_MAP:
            vk = WIN_VK_MAP[k_lower]
            if vk in (0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2D, 0x2E, 0x5B, 0x6F):
                flags |= KEYEVENTF_EXTENDEDKEY
            user32.keybd_event(vk, 0, flags, 0)
        elif len(key) == 1:
            char_code = ord(key)
            user32.keybd_event(0, char_code, flags | KEYEVENTF_UNICODE, 0)
        else:
            try:
                vk = user32.VkKeyScanW(ord(key[0])) & 0xFF
                if vk > 0:
                    user32.keybd_event(vk, 0, flags, 0)
            except Exception:
                pass

    def native_type_text(text, target_pid=None):
        for ch in text:
            char_code = ord(ch)
            user32.keybd_event(0, char_code, KEYEVENTF_UNICODE, 0)
            user32.keybd_event(0, char_code, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP, 0)

    def release_all_modifiers(target_pid=None):
        for vk in (0x10, 0x11, 0x12, 0x5B):  # Shift, Ctrl, Alt, Win
            user32.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)

else:
    # Linux / other OS fallback via PyAutoGUI if available
    try:
        import pyautogui
        pyautogui.PAUSE = 0.0
        pyautogui.FAILSAFE = False  # Disabled so moving mouse to screen corners (menus/buttons) does not crash bridge
        SCREEN_WIDTH, SCREEN_HEIGHT = pyautogui.size()

        def native_mouse_move(x, y, target_pid=None):
            pyautogui.moveTo(x, y)

        def native_mouse_down(btn, x, y, target_pid=None):
            b = 'right' if btn == 2 else ('middle' if btn == 1 else 'left')
            pyautogui.mouseDown(button=b)

        def native_mouse_up(btn, x, y, target_pid=None):
            b = 'right' if btn == 2 else ('middle' if btn == 1 else 'left')
            pyautogui.mouseUp(button=b)

        def native_mouse_click(btn, clicks, x, y, target_pid=None):
            b = 'right' if btn == 2 else ('middle' if btn == 1 else 'left')
            pyautogui.click(button=b, clicks=clicks)

        def native_scroll(units, target_pid=None):
            pyautogui.scroll(units)

        def native_key(key, is_down, modifiers=None, target_pid=None):
            pass

        def native_type_text(text, target_pid=None):
            pyautogui.typewrite(text)

        def release_all_modifiers(target_pid=None):
            pass

        def native_scroll(units):
            pyautogui.scroll(units)

        def native_key(key, is_down, modifiers=None):
            k = key.lower() if len(key) > 1 else key
            if is_down: pyautogui.keyDown(k)
            else: pyautogui.keyUp(k)

        def native_type_text(text):
            pyautogui.write(text, interval=0.01)

        def release_all_modifiers():
            for k in ('shift', 'ctrl', 'alt', 'win'):
                try: pyautogui.keyUp(k)
                except Exception: pass

    except Exception:
        print("[!] Warning: PyAutoGUI not installed on Linux/fallback OS.")
        def native_mouse_move(x, y): pass
        def native_mouse_down(btn, x, y): pass
        def native_mouse_up(btn, x, y): pass
        def native_mouse_click(btn, clicks, x, y): pass
        def native_scroll(units): pass
        def native_key(key, is_down, modifiers=None): pass
        def native_type_text(text): pass
        def release_all_modifiers(): pass


selected_display_id = None
_cached_bounds = (0, 0, 1920, 1080)
_cached_bounds_time = 0.0
_cached_display_id = None

# Screen Bounds Cache Configuration (in seconds):
# Default: 300 seconds (5 minutes). Refreshed immediately on each new connection or display selection.
# Configurable via CLI argument `--bounds-ttl <seconds>` or environment variable `P2P_BOUNDS_TTL`.
DEFAULT_BOUNDS_CACHE_TTL = float(os.environ.get("P2P_BOUNDS_TTL", 300.0))
BOUNDS_CACHE_TTL = DEFAULT_BOUNDS_CACHE_TTL

def get_screen_bounds(display_id=None, force=False):
    """
    Dynamically retrieve active screen bounds and origin with a configurable TTL cache (default 300s / 5 min).
    Refreshed on each connection attempt and whenever display selection changes.
    Eliminates OS API overhead during high-frequency mouse streaming (60-120Hz).
    """
    global SCREEN_WIDTH, SCREEN_HEIGHT, selected_display_id
    global _cached_bounds, _cached_bounds_time, _cached_display_id, BOUNDS_CACHE_TTL

    target_id = display_id if display_id is not None else selected_display_id
    now = time.monotonic()

    if not force and target_id == _cached_display_id and (now - _cached_bounds_time < BOUNDS_CACHE_TTL):
        return _cached_bounds

    if PLATFORM == 'darwin':
        target_display = target_id if (target_id is not None and int(target_id) > 0) else cg.CGMainDisplayID()
        _bounds = cg.CGDisplayBounds(target_display)
        w = int(_bounds.size.width) if _bounds.size.width > 0 else int(cg.CGDisplayPixelsWide(target_display))
        h = int(_bounds.size.height) if _bounds.size.height > 0 else int(cg.CGDisplayPixelsHigh(target_display))
        # If the target display returned 0x0 or 1x1 (invalid/detached display), fallback to CGMainDisplayID()
        if (w <= 1 or h <= 1) and target_display != cg.CGMainDisplayID():
            target_display = cg.CGMainDisplayID()
            _bounds = cg.CGDisplayBounds(target_display)
            w = int(_bounds.size.width) if _bounds.size.width > 0 else int(cg.CGDisplayPixelsWide(target_display))
            h = int(_bounds.size.height) if _bounds.size.height > 0 else int(cg.CGDisplayPixelsHigh(target_display))
        ox = int(_bounds.origin.x)
        oy = int(_bounds.origin.y)
        SCREEN_WIDTH = w if w > 0 else 1920
        SCREEN_HEIGHT = h if h > 0 else 1080
        _cached_bounds = (ox, oy, SCREEN_WIDTH, SCREEN_HEIGHT)
        _cached_bounds_time = now
        _cached_display_id = target_id
        return _cached_bounds
    elif PLATFORM == 'win32':
        try:
            import ctypes
            w = ctypes.windll.user32.GetSystemMetrics(0)
            h = ctypes.windll.user32.GetSystemMetrics(1)
            SCREEN_WIDTH = w if w > 0 else 1920
            SCREEN_HEIGHT = h if h > 0 else 1080
            _cached_bounds = (0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)
            _cached_bounds_time = now
            _cached_display_id = target_id
            return _cached_bounds
        except Exception:
            return 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT
    else:
        try:
            import pyautogui
            w, h = pyautogui.size()
            SCREEN_WIDTH = w if w > 0 else 1920
            SCREEN_HEIGHT = h if h > 0 else 1080
            _cached_bounds = (0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)
            _cached_bounds_time = now
            _cached_display_id = target_id
            return _cached_bounds
        except Exception:
            return 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT

# Initialize screen bounds at startup
get_screen_bounds(force=True)

# ── macOS Display Reconfiguration Listener ──────────────────────────────────
_display_reconfig_cb_ref = None

def _on_display_reconfiguration(display, flags, user_info):
    global _cached_bounds, _cached_bounds_time
    # kCGDisplayBeginConfigurationFlag = 1
    # Only act when the display configuration is finalized (post-configuration)
    if not (flags & 1):
        _cached_bounds = None
        _cached_bounds_time = 0.0
        ox, oy, sw, sh = get_screen_bounds(force=True)
        print(f"[Display] Reconfiguration event: display={display}, flags=0x{flags:04x} -> active bounds: {sw}x{sh} at ({ox},{oy})")
        if '_connected_control_clients' in globals() and 'make_ws_frame' in globals():
            try:
                frame = make_ws_frame(json.dumps({'t': 'screen_bounds', 'w': sw, 'h': sh, 'ox': ox, 'oy': oy, 'display': int(display)}))
                for client in list(_connected_control_clients):
                    try: client.write(frame)
                    except Exception: pass
            except Exception:
                pass

if PLATFORM == 'darwin' and 'cg' in globals() and 'CGDisplayReconfigurationCallBack' in globals():
    try:
        _display_reconfig_cb_ref = CGDisplayReconfigurationCallBack(_on_display_reconfiguration)
        _reg_ret = cg.CGDisplayRegisterReconfigurationCallback(_display_reconfig_cb_ref, None)
        if _reg_ret == 0:
            print("[Display] Registered macOS hardware display reconfiguration callback (instant geometry sync)")
    except Exception as e:
        print(f"[Display] Failed to register display reconfiguration callback: {e}")

def _cleanup_display_reconfig():
    global _display_reconfig_cb_ref
    if PLATFORM == 'darwin' and _display_reconfig_cb_ref and 'cg' in globals():
        try:
            cg.CGDisplayRemoveReconfigurationCallback(_display_reconfig_cb_ref, None)
            _display_reconfig_cb_ref = None
        except Exception:
            pass

atexit.register(_cleanup_display_reconfig)

# ── Native Clipboard Functions ───────────────────────────────────────────────
def native_set_clipboard(text):
    if not text:
        return False
    if PLATFORM == 'darwin':
        try:
            p = subprocess.Popen(['pbcopy'], stdin=subprocess.PIPE)
            p.communicate(text.encode('utf-8'))
            return True
        except Exception:
            pass
    elif PLATFORM in ('win32', 'windows'):
        try:
            p = subprocess.Popen(['clip'], stdin=subprocess.PIPE, shell=True)
            p.communicate(text.encode('utf-8'))
            return True
        except Exception:
            pass
    elif PLATFORM == 'linux':
        try:
            p = subprocess.Popen(['xclip', '-selection', 'clipboard'], stdin=subprocess.PIPE)
            p.communicate(text.encode('utf-8'))
            return True
        except Exception:
            pass
    try:
        import pyperclip
        pyperclip.copy(text)
        return True
    except Exception:
        pass
    return False


def native_get_clipboard():
    if PLATFORM == 'darwin':
        try:
            res = subprocess.run(['pbpaste'], capture_output=True, text=True, check=False, timeout=1)
            return res.stdout
        except Exception:
            pass
    elif PLATFORM in ('win32', 'windows'):
        try:
            res = subprocess.run(['powershell', '-NoProfile', '-Command', 'Get-Clipboard'], capture_output=True, text=True, check=False, timeout=1)
            return res.stdout.rstrip('\r\n')
        except Exception:
            pass
    elif PLATFORM == 'linux':
        try:
            res = subprocess.run(['xclip', '-selection', 'clipboard', '-o'], capture_output=True, text=True, check=False, timeout=1)
            return res.stdout
        except Exception:
            pass
    try:
        import pyperclip
        return pyperclip.paste()
    except Exception:
        pass
    return ""


# ── 2. Security Configuration ────────────────────────────────────────────────
TOKEN_FILE_HOME = os.path.expanduser("~/.p2p-connect-token")
TOKEN_FILE_LOCAL = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".token")
ACTIVE_TOKEN_FILE = TOKEN_FILE_HOME

DEFAULT_ALLOWED_ORIGINS = {
    "https://mahesh-devani.github.io",
    "https://localhost:8443",
    "http://localhost:8080",
    "https://127.0.0.1:8443",
    "http://127.0.0.1:8080",
}

LAN_ORIGIN_REGEX = re.compile(r'^https?://(192\.168\.\d+\.\d+|10\.\d+\.\d+\.\d+|172\.(1[6-9]|2\d|3[0-1])\.\d+\.\d+)(:\d+)?$')

def is_origin_allowed(origin):
    if not origin:
        return False
    orig = origin.strip().rstrip('/')
    if orig in ACTIVE_ALLOWED_ORIGINS:
        return True
    if orig.startswith("http://localhost") or orig.startswith("https://localhost"):
        return True
    if orig.startswith("http://127.0.0.1") or orig.startswith("https://127.0.0.1"):
        return True
    if LAN_ORIGIN_REGEX.match(orig):
        return True
    if orig == "null" or orig.startswith("file:"):
        return True
    return False

def load_or_create_token(custom_token=None):
    global ACTIVE_TOKEN_FILE
    if custom_token:
        return custom_token.strip()
    for path in [TOKEN_FILE_HOME, TOKEN_FILE_LOCAL]:
        if os.path.exists(path):
            try:
                with open(path, "r") as f:
                    tok = f.read().strip()
                    if tok:
                        ACTIVE_TOKEN_FILE = path
                        return tok
            except Exception:
                pass
    new_token = secrets.token_hex(16)
    for path in [TOKEN_FILE_HOME, TOKEN_FILE_LOCAL]:
        try:
            with open(path, "w") as f:
                f.write(new_token + "\n")
            try: os.chmod(path, 0o600)
            except Exception: pass
            ACTIVE_TOKEN_FILE = path
            return new_token
        except Exception:
            continue
    return new_token

ACTIVE_AUTH_TOKEN = ""
ACTIVE_ALLOWED_ORIGINS = set()
ALLOW_ALL_ORIGINS = False

# ── 2.1 Persistent Host Configuration & Identity ─────────────────────────────
HOST_CONFIG_DIR = os.path.expanduser("~/.p2p-connect-host")
HOST_CONFIG_FILE = os.path.join(HOST_CONFIG_DIR, "host-config.json")
_cached_host_config = None
_active_daemon_writer = None
_primary_interactive_writer = None
_connected_control_clients = set()

def load_host_config():
    global _cached_host_config
    if os.path.exists(HOST_CONFIG_FILE):
        try:
            with open(HOST_CONFIG_FILE, "r", encoding="utf-8") as f:
                _cached_host_config = json.load(f)
                return _cached_host_config
        except Exception as e:
            print(f"[!] Warning: Could not read host config: {e}")
    return None

def save_host_config(config):
    global _cached_host_config
    try:
        os.makedirs(HOST_CONFIG_DIR, exist_ok=True)
        with open(HOST_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2)
        _cached_host_config = config
        return True
    except Exception as e:
        print(f"[!] Warning: Could not write host config: {e}")
        return False

# Initialize cached config from disk on startup
load_host_config()

# ── 3. Zero-Lag Cursor Worker & Coordinate Smoothing ─────────────────────────
latest_mouse_coord = None
latest_mouse_updated = False
current_x = SCREEN_WIDTH // 2
current_y = SCREEN_HEIGHT // 2

def execute_mouse_move(x, y, target_id=None, is_window=False):
    global current_x, current_y
    if is_window:
        current_x = int(x)
        current_y = int(y)
    else:
        ox, oy, sw, sh = get_screen_bounds(target_id)
        current_x = max(ox, min(ox + sw - 1, int(x)))
        current_y = max(oy, min(oy + sh - 1, int(y)))
    native_mouse_move(current_x, current_y)

async def mouse_worker():
    global latest_mouse_coord, latest_mouse_updated
    last_applied = None

    while True:
        if latest_mouse_updated and latest_mouse_coord != last_applied:
            target = latest_mouse_coord
            latest_mouse_updated = False
            last_applied = target
            try:
                target_id = target[2] if len(target) > 2 else None
                is_win = bool(target[3]) if len(target) > 3 else False
                execute_mouse_move(target[0], target[1], target_id, is_win)
            except Exception:
                pass
        await asyncio.sleep(0.004)  # 250Hz loop

# ── 4. RFC 6455 WebSocket Implementation (Standard Library) ──────────────────
WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

# ── 5. Display Wake & Sleep Assertion Manager ────────────────────────────────
class DisplayWakeManager:
    """
    Manages transient display wake and OS sleep assertions.
    Keeps the display awake STRICTLY while an active remote desktop session
    is running, and releases the assertion as soon as the session ends so
    the host computer's display can sleep and lock naturally.
    Uses token-based tracking to ensure idempotency across multiple target switches.
    """
    def __init__(self):
        self._active_tokens = set()
        self.assertion_id = None
        self.cf_assertion_type = None
        self.cf_assertion_name = None
        self.last_wake_time = 0.0
        self._caffeinate_proc = None
        self._last_tickle_time = 0.0

    @property
    def ref_count(self):
        """Backward-compatible property for test suites and external checkers."""
        return len(self._active_tokens)

    @ref_count.setter
    def ref_count(self, val):
        if val <= 0:
            self._active_tokens.clear()
        else:
            self._active_tokens = {f"token-{i}" for i in range(val)}

    def pulse_wake(self, reason="P2P Connect Remote Desktop Wake Pulse"):
        """
        Immediately wake sleeping display and pulse WindowServer via hardware HID event source & caffeinate.
        Wakes DPMS sleeping monitors and locked loginwindow without altering password input fields.
        """
        if PLATFORM == 'darwin':
            # 1. Non-blocking one-shot user activity assertion pulse (forces display on immediately)
            try:
                subprocess.Popen(
                    ['caffeinate', '-u', '-t', '2'],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
            except Exception:
                pass

            # 2. Declare local user activity via IOKit to wake sleeping display
            try:
                iokit_path = ctypes.util.find_library('IOKit')
                cf_path = ctypes.util.find_library('CoreFoundation')
                if iokit_path and cf_path:
                    iokit = ctypes.cdll.LoadLibrary(iokit_path)
                    cf = ctypes.cdll.LoadLibrary(cf_path)
                    kCFStringEncodingUTF8 = 0x08000100
                    cf.CFStringCreateWithCString.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32]
                    cf.CFStringCreateWithCString.restype = ctypes.c_void_p
                    cf.CFRelease.argtypes = [ctypes.c_void_p]
                    cf.CFRelease.restype = None

                    name = cf.CFStringCreateWithCString(None, reason.encode('utf-8'), kCFStringEncodingUTF8)
                    wake_aid = ctypes.c_uint32(0)
                    iokit.IOPMAssertionDeclareUserActivity.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32)]
                    iokit.IOPMAssertionDeclareUserActivity.restype = ctypes.c_int
                    iokit.IOPMAssertionDeclareUserActivity(name, 0, ctypes.byref(wake_aid))
                    cf.CFRelease(name)
            except Exception:
                pass

            # 3. Simulate hardware HID keyboard interaction (Left Shift keycode 56 down & up)
            # using kCGEventSourceStateHIDSystemState (1) to wake loginwindow / DPMS monitor
            try:
                if 'cg' in globals() and hasattr(cg, 'CGEventCreateKeyboardEvent') and hasattr(cg, 'CGEventPost'):
                    src = _hid_event_source if '_hid_event_source' in globals() else None
                    # Left Shift key down & up: harmless modifier that wakes loginwindow without typing any character
                    ev_down = cg.CGEventCreateKeyboardEvent(src, 56, True)
                    if ev_down:
                        cg.CGEventPost(kCGHIDEventTap, ev_down)
                        cg.CFRelease(ev_down)
                    ev_up = cg.CGEventCreateKeyboardEvent(src, 56, False)
                    if ev_up:
                        cg.CGEventPost(kCGHIDEventTap, ev_up)
                        cg.CFRelease(ev_up)

                    # Subtle mouse jiggle with non-zero delta to satisfy WindowServer movement threshold
                    ox, oy, sw, sh = get_screen_bounds()
                    pt1 = CGPoint(ox + sw // 2 + 3, oy + sh // 2 + 3)
                    pt2 = CGPoint(ox + sw // 2, oy + sh // 2)
                    ev_m1 = cg.CGEventCreateMouseEvent(src, kCGEventMouseMoved, pt1, 0)
                    if ev_m1:
                        cg.CGEventPost(kCGHIDEventTap, ev_m1)
                        cg.CFRelease(ev_m1)
                    ev_m2 = cg.CGEventCreateMouseEvent(src, kCGEventMouseMoved, pt2, 0)
                    if ev_m2:
                        cg.CGEventPost(kCGHIDEventTap, ev_m2)
                        cg.CFRelease(ev_m2)
            except Exception as e:
                print(f"[Power] Synthetic wake event failed: {e}")

            # 4. Command WindowServer to re-assert permanent display configuration (software display bus re-sync)
            try:
                if 'cg' in globals() and hasattr(cg, 'CGRestorePermanentDisplayConfiguration'):
                    cg.CGRestorePermanentDisplayConfiguration()
            except Exception:
                pass

        elif PLATFORM == 'win32':
            try:
                ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000002 | 0x00000001)
                # Send synthetic mouse move and modifier key to wake monitor from DPMS sleep
                ctypes.windll.user32.mouse_event(0x0001, 0, 0, 0, 0)  # MOUSEEVENTF_MOVE relative (0,0)
                ctypes.windll.user32.keybd_event(0x10, 0, 0, 0)       # VK_SHIFT down
                ctypes.windll.user32.keybd_event(0x10, 0, 0x0002, 0)  # VK_SHIFT up (KEYEVENTF_KEYUP)
            except Exception:
                pass

    def wake(self, token="default", reason="P2P Connect Remote Desktop Session Active"):
        """Acquire display assertion idempotently for a given session token."""
        is_first = len(self._active_tokens) == 0
        self._active_tokens.add(token)
        now = time.monotonic()
        self.last_wake_time = now

        if PLATFORM == 'darwin':
            # 1. Continuous caffeinate process:
            # loginwindow overrides IOPMAssertionCreateWithName assertions when user is locked out.
            # Running 'caffeinate -d -u' as a persistent background process forces display & user idle stay-awake!
            if self._caffeinate_proc is None or self._caffeinate_proc.poll() is not None:
                try:
                    self._caffeinate_proc = subprocess.Popen(
                        ['caffeinate', '-w', str(os.getpid()), '-d', '-u'],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL
                    )
                    print(f"[Power] Started continuous caffeinate display wake process (PID: {self._caffeinate_proc.pid})")
                except Exception as e:
                    print(f"[Power] Could not start caffeinate: {e}")

            # 2. Pulse wake (caffeinate -u -t 2, IOKit declare user activity, Shift keypress via HID event source)
            self.pulse_wake(reason)

            # 3. Acquire IOKit PreventUserIdleDisplaySleep assertion for the session duration
            if self.assertion_id is None:
                try:
                    iokit_path = ctypes.util.find_library('IOKit')
                    cf_path = ctypes.util.find_library('CoreFoundation')
                    if iokit_path and cf_path:
                        iokit = ctypes.cdll.LoadLibrary(iokit_path)
                        cf = ctypes.cdll.LoadLibrary(cf_path)
                        kCFStringEncodingUTF8 = 0x08000100
                        cf.CFStringCreateWithCString.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32]
                        cf.CFStringCreateWithCString.restype = ctypes.c_void_p
                        cf.CFRelease.argtypes = [ctypes.c_void_p]
                        cf.CFRelease.restype = None

                        self.cf_assertion_type = cf.CFStringCreateWithCString(None, b"PreventUserIdleDisplaySleep", kCFStringEncodingUTF8)
                        self.cf_assertion_name = cf.CFStringCreateWithCString(None, reason.encode('utf-8'), kCFStringEncodingUTF8)
                        aid = ctypes.c_uint32(0)
                        iokit.IOPMAssertionCreateWithName.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32)]
                        iokit.IOPMAssertionCreateWithName.restype = ctypes.c_int

                        ret = iokit.IOPMAssertionCreateWithName(self.cf_assertion_type, 255, self.cf_assertion_name, ctypes.byref(aid))
                        if ret == 0:
                            self.assertion_id = aid.value
                            print(f"[Power] Acquired IOKit display sleep assertion (ID: {self.assertion_id})")
                except Exception as e:
                    print(f"[Power] Could not acquire IOKit assertion: {e}")

        elif PLATFORM == 'win32':
            try:
                ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000002 | 0x00000001)
                if is_first:
                    print("[Power] Acquired Windows display sleep assertion")
            except Exception as e:
                print(f"[Power] Could not acquire Win32 assertion: {e}")

        return True

    def tickle(self, token="default"):
        """Lightweight periodic or input-driven tickle to maintain display wake state."""
        now = time.monotonic()
        if now - self._last_tickle_time < 2.0:
            return
        self._last_tickle_time = now
        # Re-pulse wake if screen is locked or display is asleep
        if PLATFORM == 'darwin':
            try:
                is_asleep = False
                if 'cg' in globals() and hasattr(cg, 'CGDisplayIsAsleep') and hasattr(cg, 'CGMainDisplayID'):
                    is_asleep = bool(cg.CGDisplayIsAsleep(cg.CGMainDisplayID()))
                if is_asleep or _global_frame_capturer.is_screen_locked():
                    self.pulse_wake()
            except Exception:
                pass
        self.wake(token=token)

    def release(self, token=None, force=False):
        """Release display assertion for a token or unconditionally if force=True or token is None."""
        if force or token is None:
            self._active_tokens.clear()
        else:
            self._active_tokens.discard(token)

        if len(self._active_tokens) > 0:
            return

        print("[Power] Remote session ended: Releasing display sleep assertion (display can now sleep/lock naturally)")
        if PLATFORM == 'darwin':
            if self._caffeinate_proc is not None:
                try:
                    self._caffeinate_proc.terminate()
                    self._caffeinate_proc.wait(timeout=1.0)
                except Exception:
                    try:
                        self._caffeinate_proc.kill()
                    except Exception:
                        pass
                self._caffeinate_proc = None

            if self.assertion_id is not None:
                try:
                    iokit_path = ctypes.util.find_library('IOKit')
                    if iokit_path:
                        iokit = ctypes.cdll.LoadLibrary(iokit_path)
                        iokit.IOPMAssertionRelease.argtypes = [ctypes.c_uint32]
                        iokit.IOPMAssertionRelease.restype = ctypes.c_int
                        iokit.IOPMAssertionRelease(self.assertion_id)
                except Exception:
                    pass
                self.assertion_id = None
            if self.cf_assertion_type or self.cf_assertion_name:
                try:
                    cf_path = ctypes.util.find_library('CoreFoundation')
                    if cf_path:
                        cf = ctypes.cdll.LoadLibrary(cf_path)
                        cf.CFRelease.argtypes = [ctypes.c_void_p]
                        cf.CFRelease.restype = None
                        if self.cf_assertion_type:
                            cf.CFRelease(self.cf_assertion_type)
                            self.cf_assertion_type = None
                        if self.cf_assertion_name:
                            cf.CFRelease(self.cf_assertion_name)
                            self.cf_assertion_name = None
                except Exception:
                    pass

        elif PLATFORM == 'win32':
            try:
                ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
            except Exception:
                pass


def lock_host_screen():
    """Lock the host operating system screen immediately."""
    print("[Power] Locking host screen on remote disconnect...")
    if PLATFORM == 'darwin':
        locked = False
        try:
            login_lib = ctypes.cdll.LoadLibrary('/System/Library/PrivateFrameworks/login.framework/Versions/Current/login')
            login_lib.SACLockScreenImmediate.restype = ctypes.c_int
            login_lib.SACLockScreenImmediate.argtypes = []
            res = login_lib.SACLockScreenImmediate()
            print(f"[Power] SACLockScreenImmediate executed (return code: {res})")
            locked = True
        except Exception as e:
            print(f"[Power] SACLockScreenImmediate failed: {e}")

        if not locked:
            try:
                subprocess.run(['osascript', '-e', 'tell application "System Events" to keystroke "q" using {control down, command down}'], check=False, timeout=2.0)
                print("[Power] Screen locked via osascript (Ctrl+Cmd+Q)")
                locked = True
            except Exception as e:
                print(f"[Power] osascript lock failed: {e}")

        # Note: We intentionally avoid forcing 'pmset displaysleepnow' on session end.
        # SACLockScreenImmediate already securely locks the session. Allowing macOS to manage
        # natural display dimming/sleep prevents deep DPMS/DSC handshake freezes on ultrawide monitors.
        print("[Power] Screen locked securely; allowing natural OS display sleep to prevent DPMS freeze")

    elif PLATFORM == 'win32':
        try:
            ctypes.windll.user32.LockWorkStation()
            print("[Power] Windows workstation locked via LockWorkStation")
        except Exception as err:
            print(f"[!] Win32 LockWorkStation error: {err}")
    elif PLATFORM == 'linux':
        try:
            subprocess.run(['loginctl', 'lock-session'], check=False, timeout=2.0)
            print("[Power] Linux session locked via loginctl")
        except Exception:
            try:
                subprocess.run(['xdg-screensaver', 'lock'], check=False, timeout=2.0)
                print("[Power] Linux session locked via xdg-screensaver")
            except Exception as err:
                print(f"[!] Linux lock error: {err}")


# ── Win32 GDI+ & System Structures (Zero external dependencies) ─────────────
class GdiplusStartupInput(ctypes.Structure):
    _fields_ = [
        ("GdiplusVersion", ctypes.c_uint32),
        ("DebugEventCallback", ctypes.c_void_p),
        ("SuppressBackgroundThread", ctypes.c_bool),
        ("SuppressExternalCodecs", ctypes.c_bool)
    ]

class GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", ctypes.c_uint32),
        ("Data2", ctypes.c_uint16),
        ("Data3", ctypes.c_uint16),
        ("Data4", ctypes.c_uint8 * 8)
    ]

class EncoderParameter(ctypes.Structure):
    _fields_ = [
        ("Guid", GUID),
        ("NumberOfValues", ctypes.c_uint32),
        ("Type", ctypes.c_uint32),
        ("Value", ctypes.c_void_p)
    ]

class EncoderParameters(ctypes.Structure):
    _fields_ = [
        ("Count", ctypes.c_uint32),
        ("Parameter", EncoderParameter * 1)
    ]

CLSID_JPEG = GUID(
    0x557cf401, 0x1a04, 0x11d3,
    (ctypes.c_uint8 * 8)(0x9a, 0x73, 0x00, 0x00, 0xf8, 0x1e, 0xf3, 0x2e)
)

GUID_ENCODER_QUALITY = GUID(
    0x1d5be473, 0xaa72, 0x4b35,
    (ctypes.c_uint8 * 8)(0x83, 0x91, 0x61, 0x69, 0x3f, 0x43, 0x41, 0x7f)
)


# ── 6. Native Frame Capture Engine (Display, Window & Hardware JPEG) ─────────
class NativeFrameCapturer:
    """
    High-performance native frame capture engine with hardware JPEG compression.
    Supports physical display capture (including macOS Lock Screen) and individual
    application window capture with ZERO external pip dependencies.
    """
    def __init__(self):
        self._bounds_cache = (0, None, 0.0)
        self._last_locked_check = 0.0
        self._cached_is_locked = False
        self.jpeg_opts = None
        self._init_platform()

    def _init_platform(self):
        if PLATFORM == 'darwin':
            self.cg = ctypes.cdll.LoadLibrary(ctypes.util.find_library('CoreGraphics'))
            self.cf = ctypes.cdll.LoadLibrary(ctypes.util.find_library('CoreFoundation'))
            self.imageio = ctypes.cdll.LoadLibrary(ctypes.util.find_library('ImageIO'))

            # CoreGraphics prototypes
            self.cg.CGMainDisplayID.argtypes = []
            self.cg.CGMainDisplayID.restype = ctypes.c_uint32
            self.cg.CGDisplayBounds.argtypes = [ctypes.c_uint32]
            self.cg.CGDisplayBounds.restype = CGRect
            self.cg.CGDisplayPixelsWide.argtypes = [ctypes.c_uint32]
            self.cg.CGDisplayPixelsWide.restype = ctypes.c_size_t
            self.cg.CGDisplayPixelsHigh.argtypes = [ctypes.c_uint32]
            self.cg.CGDisplayPixelsHigh.restype = ctypes.c_size_t
            self.cg.CGGetActiveDisplayList.argtypes = [ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint32)]
            self.cg.CGGetActiveDisplayList.restype = ctypes.c_int32

            self.cg.CGDisplayCreateImage.argtypes = [ctypes.c_uint32]
            self.cg.CGDisplayCreateImage.restype = ctypes.c_void_p
            self.cg.CGWindowListCreateImage.argtypes = [CGRect, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32]
            self.cg.CGWindowListCreateImage.restype = ctypes.c_void_p
            self.cg.CGWindowListCopyWindowInfo.argtypes = [ctypes.c_uint32, ctypes.c_uint32]
            self.cg.CGWindowListCopyWindowInfo.restype = ctypes.c_void_p

            self.cg.CGImageGetWidth.argtypes = [ctypes.c_void_p]
            self.cg.CGImageGetWidth.restype = ctypes.c_size_t
            self.cg.CGImageGetHeight.argtypes = [ctypes.c_void_p]
            self.cg.CGImageGetHeight.restype = ctypes.c_size_t
            self.cg.CGImageRelease.argtypes = [ctypes.c_void_p]

            # ImageIO prototypes
            self.imageio.CGImageDestinationCreateWithData.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p]
            self.imageio.CGImageDestinationCreateWithData.restype = ctypes.c_void_p
            self.imageio.CGImageDestinationAddImage.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
            self.imageio.CGImageDestinationAddImage.restype = None
            self.imageio.CGImageDestinationFinalize.argtypes = [ctypes.c_void_p]
            self.imageio.CGImageDestinationFinalize.restype = ctypes.c_bool

            # CoreFoundation prototypes
            self.cf.CFDataCreateMutable.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
            self.cf.CFDataCreateMutable.restype = ctypes.c_void_p
            self.cf.CFDataGetLength.argtypes = [ctypes.c_void_p]
            self.cf.CFDataGetLength.restype = ctypes.c_size_t
            self.cf.CFDataGetBytePtr.argtypes = [ctypes.c_void_p]
            self.cf.CFDataGetBytePtr.restype = ctypes.c_void_p
            self.cf.CFRelease.argtypes = [ctypes.c_void_p]

            self.cf.CFArrayGetCount.argtypes = [ctypes.c_void_p]
            self.cf.CFArrayGetCount.restype = ctypes.c_size_t
            self.cf.CFArrayGetValueAtIndex.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
            self.cf.CFArrayGetValueAtIndex.restype = ctypes.c_void_p

            self.cf.CFDictionaryGetValue.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
            self.cf.CFDictionaryGetValue.restype = ctypes.c_void_p

            self.cf.CFNumberGetValue.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
            self.cf.CFNumberGetValue.restype = ctypes.c_bool

            self.cf.CFStringGetCString.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t, ctypes.c_uint32]
            self.cf.CFStringGetCString.restype = ctypes.c_bool

            kCFStringEncodingUTF8 = 0x08000100
            self.cf.CFStringCreateWithCString.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32]
            self.cf.CFStringCreateWithCString.restype = ctypes.c_void_p
            self.cf.CFRelease.argtypes = [ctypes.c_void_p]
            self.cf.CFRelease.restype = None

            self.jpeg_type = self.cf.CFStringCreateWithCString(None, b'public.jpeg', kCFStringEncodingUTF8)
            self.k_num = self.cf.CFStringCreateWithCString(None, b'kCGWindowNumber', kCFStringEncodingUTF8)
            self.k_bounds = self.cf.CFStringCreateWithCString(None, b'kCGWindowBounds', kCFStringEncodingUTF8)
            self.k_x = self.cf.CFStringCreateWithCString(None, b'X', kCFStringEncodingUTF8)
            self.k_y = self.cf.CFStringCreateWithCString(None, b'Y', kCFStringEncodingUTF8)
            self.k_w = self.cf.CFStringCreateWithCString(None, b'Width', kCFStringEncodingUTF8)
            self.k_h = self.cf.CFStringCreateWithCString(None, b'Height', kCFStringEncodingUTF8)
            self.k_owner = self.cf.CFStringCreateWithCString(None, b'kCGWindowOwnerName', kCFStringEncodingUTF8)
            self.k_name = self.cf.CFStringCreateWithCString(None, b'kCGWindowName', kCFStringEncodingUTF8)
            self.k_layer = self.cf.CFStringCreateWithCString(None, b'kCGWindowLayer', kCFStringEncodingUTF8)
            self.k_pid = self.cf.CFStringCreateWithCString(None, b'kCGWindowOwnerPID', kCFStringEncodingUTF8)
            self.k_locked = self.cf.CFStringCreateWithCString(None, b'CGSSessionScreenIsLocked', kCFStringEncodingUTF8)
            self.null_rect = CGRect(CGPoint(float('inf'), float('inf')), CGSize(0, 0))

            # Native AppKit Cocoa bindings for instant, zero-dependency window activation & focus
            try:
                ctypes.cdll.LoadLibrary('/System/Library/Frameworks/AppKit.framework/AppKit')
                objc = ctypes.cdll.LoadLibrary(ctypes.util.find_library('objc'))
                objc.objc_getClass.restype = ctypes.c_void_p
                objc.objc_getClass.argtypes = [ctypes.c_char_p]
                objc.sel_registerName.restype = ctypes.c_void_p
                objc.sel_registerName.argtypes = [ctypes.c_char_p]

                self._NSRunningApplication = objc.objc_getClass(b'NSRunningApplication')
                self._sel_appWithPID = objc.sel_registerName(b'runningApplicationWithProcessIdentifier:')
                self._sel_activate = objc.sel_registerName(b'activateWithOptions:')
                self._msgSend_pid = ctypes.cast(objc.objc_msgSend, ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32))
                self._msgSend_act = ctypes.cast(objc.objc_msgSend, ctypes.CFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong))

                # Ensure process runs as background accessory (hides Python rocket icon from Dock and prevents bounce)
                try:
                    NSApplication = objc.objc_getClass(b'NSApplication')
                    sel_shared = objc.sel_registerName(b'sharedApplication')
                    sel_setPolicy = objc.sel_registerName(b'setActivationPolicy:')
                    msgSend_noargs = ctypes.cast(objc.objc_msgSend, ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p))
                    msgSend_policy = ctypes.cast(objc.objc_msgSend, ctypes.CFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_long))
                    ns_app = msgSend_noargs(NSApplication, sel_shared)
                    if ns_app:
                        # 2 = NSApplicationActivationPolicyProhibited (completely hidden from Dock & App Switcher)
                        msgSend_policy(ns_app, sel_setPolicy, 2)
                except Exception:
                    pass
            except Exception:
                self._NSRunningApplication = None

            # Native Accessibility (AXUIElement) C bindings for instant window raise & unminimize without AppleEvents TCC prompts
            try:
                self.app_services = ctypes.cdll.LoadLibrary('/System/Library/Frameworks/ApplicationServices.framework/ApplicationServices')
                self.ax_create_app = self.app_services.AXUIElementCreateApplication
                self.ax_create_app.argtypes = [ctypes.c_int32]
                self.ax_create_app.restype = ctypes.c_void_p

                self.ax_copy_attr = self.app_services.AXUIElementCopyAttributeValue
                self.ax_copy_attr.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
                self.ax_copy_attr.restype = ctypes.c_int32

                self.ax_set_attr = self.app_services.AXUIElementSetAttributeValue
                self.ax_set_attr.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
                self.ax_set_attr.restype = ctypes.c_int32

                self.ax_perform = self.app_services.AXUIElementPerformAction
                self.ax_perform.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
                self.ax_perform.restype = ctypes.c_int32

                self.k_ax_windows = self.cf.CFStringCreateWithCString(None, b'AXWindows', kCFStringEncodingUTF8)
                self.k_ax_raise = self.cf.CFStringCreateWithCString(None, b'AXRaise', kCFStringEncodingUTF8)
                self.k_ax_min = self.cf.CFStringCreateWithCString(None, b'AXMinimized', kCFStringEncodingUTF8)
                self.k_cf_false = ctypes.c_void_p.in_dll(self.cf, 'kCFBooleanFalse')
            except Exception:
                self.ax_create_app = None

            self.cg.CGSessionCopyCurrentDictionary.argtypes = []
            self.cg.CGSessionCopyCurrentDictionary.restype = ctypes.c_void_p
            self.cf.CFBooleanGetValue.argtypes = [ctypes.c_void_p]
            self.cf.CFBooleanGetValue.restype = ctypes.c_bool

            # Quality dictionary for ImageIO JPEG compression (0.85 = crisp text & crystal clear display)
            try:
                self.cf.CFNumberCreate.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
                self.cf.CFNumberCreate.restype = ctypes.c_void_p
                k_quality = self.cf.CFStringCreateWithCString(None, b'kCGImageDestinationLossyCompressionQuality', kCFStringEncodingUTF8)
                q_val = ctypes.c_float(0.85)
                q_num = self.cf.CFNumberCreate(None, 12, ctypes.byref(q_val))
                keys = (ctypes.c_void_p * 1)(k_quality)
                vals = (ctypes.c_void_p * 1)(q_num)
                self.cf.CFDictionaryCreate.argtypes = [
                    ctypes.c_void_p,
                    ctypes.POINTER(ctypes.c_void_p),
                    ctypes.POINTER(ctypes.c_void_p),
                    ctypes.c_size_t,
                    ctypes.c_void_p,
                    ctypes.c_void_p
                ]
                self.cf.CFDictionaryCreate.restype = ctypes.c_void_p
                key_callbacks = ctypes.c_void_p.in_dll(self.cf, 'kCFTypeDictionaryKeyCallBacks')
                val_callbacks = ctypes.c_void_p.in_dll(self.cf, 'kCFTypeDictionaryValueCallBacks')
                self.jpeg_opts = self.cf.CFDictionaryCreate(None, keys, vals, 1, ctypes.byref(key_callbacks), ctypes.byref(val_callbacks))
                self.cf.CFRelease(k_quality)
                self.cf.CFRelease(q_num)
            except Exception:
                self.jpeg_opts = None

        elif PLATFORM == 'win32':
            self._has_pillow = False
            try:
                from PIL import ImageGrab
                import io
                self._pillow_imagegrab = ImageGrab
                self._io = io
                self._has_pillow = True
            except Exception:
                pass

            self._has_gdiplus = False
            try:
                self.user32 = ctypes.windll.user32
                self.gdi32 = ctypes.windll.gdi32
                self.ole32 = ctypes.windll.ole32
                self.kernel32 = ctypes.windll.kernel32
                self.gdiplus = ctypes.windll.gdiplus

                try:
                    ctypes.windll.shcore.SetProcessDpiAwareness(2)
                except Exception:
                    try:
                        self.user32.SetProcessDPIAware()
                    except Exception:
                        pass

                self.gdiplus_token = ctypes.c_ulong()
                startup_in = GdiplusStartupInput(1, None, False, False)
                if self.gdiplus.GdiplusStartup(ctypes.byref(self.gdiplus_token), ctypes.byref(startup_in), None) == 0:
                    self._has_gdiplus = True

                self.quality_val = ctypes.c_uint32(85)
                self.enc_params = EncoderParameters()
                self.enc_params.Count = 1
                self.enc_params.Parameter[0].Guid = GUID_ENCODER_QUALITY
                self.enc_params.Parameter[0].NumberOfValues = 1
                self.enc_params.Parameter[0].Type = 4  # EncoderParameterValueTypeLong
                self.enc_params.Parameter[0].Value = ctypes.cast(ctypes.byref(self.quality_val), ctypes.c_void_p)

                self.kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
                self.kernel32.GlobalLock.restype = ctypes.c_void_p
                self.kernel32.GlobalSize.argtypes = [ctypes.c_void_p]
                self.kernel32.GlobalSize.restype = ctypes.c_size_t
                self.kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
                self.kernel32.GlobalUnlock.restype = ctypes.c_bool

                # Explicit 64-bit function prototypes for window activation & input targeting
                self.user32.GetForegroundWindow.argtypes = []
                self.user32.GetForegroundWindow.restype = ctypes.c_void_p
                self.user32.SetFocus.argtypes = [ctypes.c_void_p]
                self.user32.SetFocus.restype = ctypes.c_void_p
                self.user32.IsWindow.argtypes = [ctypes.c_void_p]
                self.user32.IsWindow.restype = ctypes.c_bool
                self.user32.IsIconic.argtypes = [ctypes.c_void_p]
                self.user32.IsIconic.restype = ctypes.c_bool
                self.user32.ShowWindow.argtypes = [ctypes.c_void_p, ctypes.c_int]
                self.user32.ShowWindow.restype = ctypes.c_bool
                self.user32.BringWindowToTop.argtypes = [ctypes.c_void_p]
                self.user32.BringWindowToTop.restype = ctypes.c_bool
                self.user32.SetForegroundWindow.argtypes = [ctypes.c_void_p]
                self.user32.SetForegroundWindow.restype = ctypes.c_bool
                self.user32.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
                self.user32.SetWindowPos.restype = ctypes.c_bool
                self.user32.AttachThreadInput.argtypes = [ctypes.c_ulong, ctypes.c_ulong, ctypes.c_bool]
                self.user32.AttachThreadInput.restype = ctypes.c_bool
                self.kernel32.GetCurrentThreadId.argtypes = []
                self.kernel32.GetCurrentThreadId.restype = ctypes.c_ulong
                self.user32.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
                self.user32.GetWindowThreadProcessId.restype = ctypes.c_ulong
            except Exception as e:
                print(f"[!] Win32 GDI+ initialization warning: {e}")

    def is_screen_locked(self, max_age=1.0):
        """Check if OS user session is currently locked (cached with max_age to prevent IPC flooding)."""
        now = time.monotonic()
        if (now - self._last_locked_check) < max_age:
            return self._cached_is_locked
        self._last_locked_check = now
        if PLATFORM == 'darwin':
            try:
                d = self.cg.CGSessionCopyCurrentDictionary()
                if not d:
                    self._cached_is_locked = False
                    return False
                val = self.cf.CFDictionaryGetValue(d, self.k_locked)
                is_locked = bool(self.cf.CFBooleanGetValue(val)) if val else False
                self.cf.CFRelease(d)
                self._cached_is_locked = is_locked
                return is_locked
            except Exception:
                self._cached_is_locked = False
                return False
        elif PLATFORM == 'win32':
            try:
                # On Windows, when locked, user desktop switches to Winlogon/secure desktop.
                # OpenInputDesktop fails with ERROR_ACCESS_DENIED (5) when locked.
                hdesk = ctypes.windll.user32.OpenInputDesktop(0, False, 0x0001)  # DESKTOP_READOBJECTS
                if hdesk:
                    ctypes.windll.user32.CloseDesktop(hdesk)
                    self._cached_is_locked = False
                    return False
                else:
                    self._cached_is_locked = True
                    return True
            except Exception:
                self._cached_is_locked = False
                return False
        self._cached_is_locked = False
        return False

    def capture_display(self, display_id=None):
        if PLATFORM == 'darwin':
            d_id = int(display_id) if (display_id and int(display_id) > 0) else self.cg.CGMainDisplayID()
            b = self.cg.CGDisplayBounds(d_id)
            if (b.size.width <= 1 or b.size.height <= 1) and d_id != self.cg.CGMainDisplayID():
                d_id = self.cg.CGMainDisplayID()
            img = self.cg.CGDisplayCreateImage(d_id)
            if not img and d_id != self.cg.CGMainDisplayID():
                img = self.cg.CGDisplayCreateImage(self.cg.CGMainDisplayID())
            return self._compress_cg_image(img)
        elif PLATFORM == 'win32':
            return self._capture_display_win32(display_id)
        return None, 0, 0

    def capture_window(self, window_id):
        if PLATFORM == 'darwin':
            b = self.get_window_bounds(window_id)
            if b:
                wx, wy, ww, wh = b
                win_rect = CGRect(CGPoint(float(wx), float(wy)), CGSize(float(ww), float(wh)))
            else:
                win_rect = self.null_rect
            # 10 = kCGWindowListOptionOnScreenAboveWindow (2) | kCGWindowListOptionIncludingWindow (8)
            # Captures the window AND all attached popup menus, dropdowns, combo boxes, context menus & dialogs!
            # 1 = kCGWindowImageBoundsIgnoreFraming (omits drop shadow / framing, eliminating white borders and aligning mouse coordinates)
            img = self.cg.CGWindowListCreateImage(win_rect, 10, int(window_id), 1)
            if not img and b:
                # Fallback to single-window capture if above-window capture returns None
                img = self.cg.CGWindowListCreateImage(win_rect, 8, int(window_id), 1)
            return self._compress_cg_image(img)
        elif PLATFORM == 'win32' and int(window_id or 0) > 0:
            return self._capture_window_win32(window_id)
        return None, 0, 0

    def _capture_display_win32(self, display_id=None):
        ox, oy, w, h = get_screen_bounds(display_id)
        if w <= 0 or h <= 0:
            return None, 0, 0

        # Fast path: Pillow if available
        if getattr(self, '_has_pillow', False):
            try:
                img = self._pillow_imagegrab.grab(bbox=(ox, oy, ox + w, oy + h), all_screens=True)
                buf = self._io.BytesIO()
                img.save(buf, format='JPEG', quality=85)
                return buf.getvalue(), img.width, img.height
            except Exception:
                pass

        # Native Zero-Dependency GDI+ path
        if not getattr(self, '_has_gdiplus', False):
            return None, 0, 0

        hdc_screen = None
        hdc_mem = None
        hbm = None
        old_hbm = None
        p_bitmap = None
        p_stream = None

        try:
            hdc_screen = self.user32.GetDC(0)
            if not hdc_screen:
                return None, 0, 0

            hdc_mem = self.gdi32.CreateCompatibleDC(hdc_screen)
            hbm = self.gdi32.CreateCompatibleBitmap(hdc_screen, w, h)
            old_hbm = self.gdi32.SelectObject(hdc_mem, hbm)

            # SRCCOPY (0x00CC0020) | CAPTUREBLT (0x40000000) captures layered windows/menus
            self.gdi32.BitBlt(hdc_mem, 0, 0, w, h, hdc_screen, ox, oy, 0x00CC0020 | 0x40000000)

            p_bitmap = ctypes.c_void_p()
            if self.gdiplus.GdipCreateBitmapFromHBITMAP(hbm, 0, ctypes.byref(p_bitmap)) != 0 or not p_bitmap:
                return None, 0, 0

            p_stream = ctypes.c_void_p()
            if self.ole32.CreateStreamOnHGlobal(0, True, ctypes.byref(p_stream)) != 0 or not p_stream:
                return None, 0, 0

            if self.gdiplus.GdipSaveImageToStream(p_bitmap, p_stream, ctypes.byref(CLSID_JPEG), ctypes.byref(self.enc_params)) != 0:
                return None, 0, 0

            hglobal = ctypes.c_void_p()
            if self.ole32.GetHGlobalFromStream(p_stream, ctypes.byref(hglobal)) != 0 or not hglobal:
                return None, 0, 0

            ptr = self.kernel32.GlobalLock(hglobal)
            length = self.kernel32.GlobalSize(hglobal)
            jpeg_bytes = ctypes.string_at(ptr, length) if (ptr and length > 0) else None
            self.kernel32.GlobalUnlock(hglobal)

            return jpeg_bytes, w, h
        except Exception:
            return None, 0, 0
        finally:
            if p_bitmap:
                try: self.gdiplus.GdipDisposeImage(p_bitmap)
                except Exception: pass
            if p_stream:
                try:
                    vtable = ctypes.cast(p_stream, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
                    release_fn = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vtable[2])
                    release_fn(p_stream)
                except Exception: pass
            if old_hbm and hdc_mem:
                try: self.gdi32.SelectObject(hdc_mem, old_hbm)
                except Exception: pass
            if hbm:
                try: self.gdi32.DeleteObject(hbm)
                except Exception: pass
            if hdc_mem:
                try: self.gdi32.DeleteDC(hdc_mem)
                except Exception: pass
            if hdc_screen:
                try: self.user32.ReleaseDC(0, hdc_screen)
                except Exception: pass

    def _capture_window_win32(self, window_id):
        b = self.get_window_bounds(window_id)
        if not b:
            return self.capture_display()
        wx, wy, ww, wh = b
        if ww <= 0 or wh <= 0:
            return self.capture_display()

        hwnd = int(window_id)
        if not getattr(self, '_has_gdiplus', False):
            return None, 0, 0

        hdc_win = None
        hdc_mem = None
        hbm = None
        old_hbm = None
        p_bitmap = None
        p_stream = None

        try:
            hdc_win = self.user32.GetWindowDC(hwnd)
            if not hdc_win:
                hdc_win = self.user32.GetDC(0)
            hdc_mem = self.gdi32.CreateCompatibleDC(hdc_win)
            hbm = self.gdi32.CreateCompatibleBitmap(hdc_win, ww, wh)
            old_hbm = self.gdi32.SelectObject(hdc_mem, hbm)

            # PW_RENDERFULLCONTENT = 2 on Windows 8.1+
            ret = self.user32.PrintWindow(hwnd, hdc_mem, 2)
            if not ret:
                hdc_screen = self.user32.GetDC(0)
                self.gdi32.BitBlt(hdc_mem, 0, 0, ww, wh, hdc_screen, wx, wy, 0x00CC0020 | 0x40000000)
                self.user32.ReleaseDC(0, hdc_screen)

            p_bitmap = ctypes.c_void_p()
            if self.gdiplus.GdipCreateBitmapFromHBITMAP(hbm, 0, ctypes.byref(p_bitmap)) != 0 or not p_bitmap:
                return None, 0, 0

            p_stream = ctypes.c_void_p()
            if self.ole32.CreateStreamOnHGlobal(0, True, ctypes.byref(p_stream)) != 0 or not p_stream:
                return None, 0, 0

            if self.gdiplus.GdipSaveImageToStream(p_bitmap, p_stream, ctypes.byref(CLSID_JPEG), ctypes.byref(self.enc_params)) != 0:
                return None, 0, 0

            hglobal = ctypes.c_void_p()
            if self.ole32.GetHGlobalFromStream(p_stream, ctypes.byref(hglobal)) != 0 or not hglobal:
                return None, 0, 0

            ptr = self.kernel32.GlobalLock(hglobal)
            length = self.kernel32.GlobalSize(hglobal)
            jpeg_bytes = ctypes.string_at(ptr, length) if (ptr and length > 0) else None
            self.kernel32.GlobalUnlock(hglobal)

            return jpeg_bytes, ww, wh
        except Exception:
            return None, 0, 0
        finally:
            if p_bitmap:
                try: self.gdiplus.GdipDisposeImage(p_bitmap)
                except Exception: pass
            if p_stream:
                try:
                    vtable = ctypes.cast(p_stream, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
                    release_fn = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vtable[2])
                    release_fn(p_stream)
                except Exception: pass
            if old_hbm and hdc_mem:
                try: self.gdi32.SelectObject(hdc_mem, old_hbm)
                except Exception: pass
            if hbm:
                try: self.gdi32.DeleteObject(hbm)
                except Exception: pass
            if hdc_mem:
                try: self.gdi32.DeleteDC(hdc_mem)
                except Exception: pass
            if hdc_win:
                try: self.user32.ReleaseDC(hwnd, hdc_win)
                except Exception: pass

    def _compress_cg_image(self, img):
        if not img:
            return None, 0, 0
        try:
            w = self.cg.CGImageGetWidth(img)
            h = self.cg.CGImageGetHeight(img)
            data_buf = self.cf.CFDataCreateMutable(None, 0)
            dest = self.imageio.CGImageDestinationCreateWithData(data_buf, self.jpeg_type, 1, None)
            self.imageio.CGImageDestinationAddImage(dest, img, self.jpeg_opts)
            self.imageio.CGImageDestinationFinalize(dest)
            self.cg.CGImageRelease(img)
            self.cf.CFRelease(dest)

            length = self.cf.CFDataGetLength(data_buf)
            ptr = self.cf.CFDataGetBytePtr(data_buf)
            py_bytes = ctypes.string_at(ptr, length)
            self.cf.CFRelease(data_buf)
            return py_bytes, w, h
        except Exception:
            if img:
                try: self.cg.CGImageRelease(img)
                except Exception: pass
            return None, 0, 0

    def enumerate_targets(self):
        displays = []
        windows = []
        if PLATFORM == 'darwin':
            # 1. Displays
            try:
                max_displays = 16
                active_displays = (ctypes.c_uint32 * max_displays)()
                display_count = ctypes.c_uint32()
                # Use CGGetOnlineDisplayList so all attached and active hardware displays are discovered
                # even when bridge is running inside an interactive terminal, SSH, or headless service
                res = self.cg.CGGetOnlineDisplayList(max_displays, active_displays, ctypes.byref(display_count))
                if res != 0 or display_count.value == 0:
                    res = self.cg.CGGetActiveDisplayList(max_displays, active_displays, ctypes.byref(display_count))
                if res == 0 and display_count.value > 0:
                    for i in range(display_count.value):
                        d_id = active_displays[i]
                        b = self.cg.CGDisplayBounds(d_id)
                        w = int(b.size.width) if b.size.width > 0 else int(self.cg.CGDisplayPixelsWide(d_id))
                        h = int(b.size.height) if b.size.height > 0 else int(self.cg.CGDisplayPixelsHigh(d_id))
                        if w <= 1 or h <= 1:
                            continue
                        is_main = (d_id == self.cg.CGMainDisplayID())
                        displays.append({
                            'id': int(d_id),
                            'index': i + 1,
                            'name': f"Display {i + 1} ({w}x{h})" if not is_main else f"Main Display ({w}x{h})",
                            'width': w,
                            'height': h,
                            'is_main': is_main
                        })
            except Exception:
                pass

            # 2. Windows
            try:
                kCGWindowListOptionOnScreenOnly = 1
                kCGWindowListExcludeDesktopElements = 16
                arr = self.cg.CGWindowListCopyWindowInfo(kCGWindowListOptionOnScreenOnly | kCGWindowListExcludeDesktopElements, 0)
                if arr:
                    count = self.cf.CFArrayGetCount(arr)
                    buf = ctypes.create_string_buffer(256)
                    for i in range(count):
                        d = self.cf.CFArrayGetValueAtIndex(arr, i)
                        layer = ctypes.c_int32(0)
                        l_ref = self.cf.CFDictionaryGetValue(d, self.k_layer)
                        if l_ref:
                            self.cf.CFNumberGetValue(l_ref, 3, ctypes.byref(layer))
                        if layer.value != 0:
                            continue
                        num_ref = self.cf.CFDictionaryGetValue(d, self.k_num)
                        wid = ctypes.c_uint32(0)
                        if num_ref:
                            self.cf.CFNumberGetValue(num_ref, 3, ctypes.byref(wid))
                        
                        owner_ref = self.cf.CFDictionaryGetValue(d, self.k_owner)
                        owner = ''
                        if owner_ref and self.cf.CFStringGetCString(owner_ref, buf, 256, 0x08000100):
                            owner = buf.value.decode('utf-8', errors='ignore')

                        name_ref = self.cf.CFDictionaryGetValue(d, self.k_name)
                        name = ''
                        if name_ref and self.cf.CFStringGetCString(name_ref, buf, 256, 0x08000100):
                            name = buf.value.decode('utf-8', errors='ignore')

                        if owner and owner not in ('Window Server', 'Dock', 'ControlCenter', 'Notification Centre'):
                            title = f"{owner} - {name}" if name else owner
                            windows.append({
                                'id': int(wid.value),
                                'owner': owner,
                                'name': name,
                                'title': title
                            })
                    self.cf.CFRelease(arr)
            except Exception:
                pass

        elif PLATFORM == 'win32':
            # 1. Displays via EnumDisplayMonitors
            try:
                from ctypes import wintypes
                monitors = []
                def monitor_enum_proc(hMonitor, hdcMonitor, lprcMonitor, dwData):
                    monitors.append(hMonitor)
                    return 1

                MONITORENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p)
                ctypes.windll.user32.EnumDisplayMonitors(0, 0, MONITORENUMPROC(monitor_enum_proc), 0)

                class MONITORINFOEXW(ctypes.Structure):
                    _fields_ = [
                        ('cbSize', ctypes.c_uint32),
                        ('rcMonitor', wintypes.RECT),
                        ('rcWork', wintypes.RECT),
                        ('dwFlags', ctypes.c_uint32),
                        ('szDevice', ctypes.c_wchar * 32)
                    ]

                for idx, hMon in enumerate(monitors):
                    info = MONITORINFOEXW()
                    info.cbSize = ctypes.sizeof(MONITORINFOEXW)
                    if ctypes.windll.user32.GetMonitorInfoW(hMon, ctypes.byref(info)):
                        r = info.rcMonitor
                        mw = r.right - r.left
                        mh = r.bottom - r.top
                        is_primary = bool(info.dwFlags & 1)
                        dev_name = info.szDevice or f"Display {idx + 1}"
                        displays.append({
                            'id': idx + 1,
                            'index': idx + 1,
                            'name': f"{dev_name} ({mw}x{mh})" + (" [Primary]" if is_primary else ""),
                            'width': mw,
                            'height': mh,
                            'is_main': is_primary
                        })
            except Exception:
                pass

            # 2. Windows via EnumWindows
            try:
                def enum_win_proc(hwnd, lParam):
                    if ctypes.windll.user32.IsWindowVisible(hwnd):
                        length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
                        if length > 0:
                            buf = ctypes.create_unicode_buffer(length + 1)
                            ctypes.windll.user32.GetWindowTextW(hwnd, buf, length + 1)
                            title = buf.value.strip()
                            if title and title not in ('Program Manager', 'Settings', 'Windows Shell Experience Host'):
                                windows.append({
                                    'id': int(hwnd),
                                    'owner': title.split(' - ')[-1] if ' - ' in title else title,
                                    'name': title,
                                    'title': title
                                })
                    return 1

                WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p)
                ctypes.windll.user32.EnumWindows(WNDENUMPROC(enum_win_proc), 0)
            except Exception:
                pass

        if not displays:
            main_id = int(self.cg.CGMainDisplayID()) if PLATFORM == 'darwin' else 1
            displays.append({
                'id': main_id,
                'index': 1,
                'name': f"Main Display ({SCREEN_WIDTH}x{SCREEN_HEIGHT})",
                'width': SCREEN_WIDTH,
                'height': SCREEN_HEIGHT,
                'is_main': True
            })

        return {'displays': displays, 'windows': windows}

    def ns_app_activate(self, pid):
        if not getattr(self, '_NSRunningApplication', None) or not pid:
            return False
        try:
            app = self._msgSend_pid(self._NSRunningApplication, self._sel_appWithPID, int(pid))
            if app:
                # 3 = NSApplicationActivateAllWindows (1) | NSApplicationActivateIgnoringOtherApps (2)
                return bool(self._msgSend_act(app, self._sel_activate, 3))
        except Exception:
            pass
        return False

    def ax_raise_windows(self, pid):
        """
        Unminimizes and raises windows of target PID using native macOS C Accessibility API (AXUIElement).
        Inherits established Accessibility permission without triggering per-app Automation TCC prompts.
        """
        if not getattr(self, 'ax_create_app', None) or not pid:
            return False
        try:
            app_elem = self.ax_create_app(int(pid))
            if not app_elem:
                return False
            win_list = ctypes.c_void_p()
            if self.ax_copy_attr(app_elem, self.k_ax_windows, ctypes.byref(win_list)) == 0 and win_list:
                count = self.cf.CFArrayGetCount(win_list)
                for i in range(count):
                    w_elem = self.cf.CFArrayGetValueAtIndex(win_list, i)
                    if w_elem:
                        # Restore window if minimized
                        self.ax_set_attr(w_elem, self.k_ax_min, self.k_cf_false)
                        # Raise window to the front
                        self.ax_perform(w_elem, self.k_ax_raise)
                self.cf.CFRelease(win_list)
            self.cf.CFRelease(app_elem)
            return True
        except Exception:
            return False

    def get_window_info(self, window_id):
        if not window_id:
            return None
        try:
            wid = int(window_id)
        except Exception:
            return None
        if wid <= 0:
            return None

        now = time.monotonic()
        if hasattr(self, '_window_info_cache') and wid in self._window_info_cache:
            cached_data, cached_t = self._window_info_cache[wid]
            if (now - cached_t) < 1.0:
                return cached_data

        if PLATFORM == 'darwin':
            try:
                # kCGWindowListOptionAll = 0: find window across all states (even background, minimized or obscured)
                arr = self.cg.CGWindowListCopyWindowInfo(0, 0)
                if arr:
                    count = self.cf.CFArrayGetCount(arr)
                    k_pid = getattr(self, 'k_pid', None) or self.cf.CFStringCreateWithCString(None, b"kCGWindowOwnerPID", 0x08000100)
                    wid_c = ctypes.c_uint32(0)
                    pid_c = ctypes.c_int32(0)
                    buf = ctypes.create_string_buffer(256)
                    info = None
                    for i in range(count):
                        d = self.cf.CFArrayGetValueAtIndex(arr, i)
                        num_ref = self.cf.CFDictionaryGetValue(d, self.k_num)
                        if num_ref:
                            wid_c.value = 0
                            self.cf.CFNumberGetValue(num_ref, 3, ctypes.byref(wid_c))
                            if wid_c.value == wid:
                                target_pid = None
                                pid_ref = self.cf.CFDictionaryGetValue(d, k_pid)
                                if pid_ref:
                                    self.cf.CFNumberGetValue(pid_ref, 3, ctypes.byref(pid_c))
                                    target_pid = pid_c.value

                                owner_str = ''
                                owner_ref = self.cf.CFDictionaryGetValue(d, self.k_owner)
                                if owner_ref:
                                    self.cf.CFStringGetCString(owner_ref, buf, 256, 0x08000100)
                                    owner_str = buf.value.decode('utf-8', 'replace')

                                name_str = ''
                                name_ref = self.cf.CFDictionaryGetValue(d, self.k_name)
                                if name_ref:
                                    self.cf.CFStringGetCString(name_ref, buf, 256, 0x08000100)
                                    name_str = buf.value.decode('utf-8', 'replace')

                                bounds_ref = self.cf.CFDictionaryGetValue(d, self.k_bounds)
                                target_bounds = None
                                if bounds_ref:
                                    def _get_val(k):
                                        ref = self.cf.CFDictionaryGetValue(bounds_ref, k)
                                        if not ref: return 0.0
                                        val = ctypes.c_double(0)
                                        self.cf.CFNumberGetValue(ref, 13, ctypes.byref(val))
                                        return val.value
                                    x = int(_get_val(self.k_x))
                                    y = int(_get_val(self.k_y))
                                    w = int(_get_val(self.k_w))
                                    h = int(_get_val(self.k_h))
                                    if w > 0 and h > 0:
                                        target_bounds = (x, y, w, h)

                                info = {
                                    'pid': target_pid,
                                    'owner': owner_str,
                                    'name': name_str,
                                    'bounds': target_bounds
                                }
                                break
                    self.cf.CFRelease(arr)
                    if info:
                        if not hasattr(self, '_window_info_cache'):
                            self._window_info_cache = {}
                        self._window_info_cache[wid] = (info, now)
                        return info
            except Exception:
                pass
        return None

    def get_window_pid(self, window_id):
        info = self.get_window_info(window_id)
        return info.get('pid') if info else None

    def get_window_bounds(self, window_id, force=False):
        now = time.monotonic()
        if not force and hasattr(self, '_bounds_cache'):
            cached_wid, cached_b, cached_t = self._bounds_cache
            if cached_wid == int(window_id) and cached_b and (now - cached_t < 0.5):
                return cached_b

        if PLATFORM == 'darwin' and window_id > 0:
            info = self.get_window_info(window_id)
            if info and info.get('bounds'):
                self._bounds_cache = (int(window_id), info['bounds'], now)
                return info['bounds']
            return None
        elif PLATFORM == 'win32' and window_id > 0:
            try:
                from ctypes import wintypes
                rect = wintypes.RECT()
                if ctypes.windll.user32.GetWindowRect(int(window_id), ctypes.byref(rect)):
                    res = (rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top)
                    self._bounds_cache = (int(window_id), res, now)
                    return res
            except Exception:
                pass
        return None

    def activate_window(self, window_id):
        """
        Brings the specified window to the top of the Z-order, restores it if minimized,
        and assigns it OS foreground focus so that both mouse clicks and keyboard typing
        are delivered directly to the target application.
        """
        if not window_id:
            return False
        try:
            wid = int(window_id)
        except Exception:
            return False
        if wid <= 0:
            return False

        if PLATFORM == 'win32':
            try:
                hwnd = wid
                if not getattr(self, 'user32', None) or not self.user32.IsWindow(hwnd):
                    return False

                # 1. Restore window if minimized
                if self.user32.IsIconic(hwnd):
                    self.user32.ShowWindow(hwnd, 9)  # SW_RESTORE
                else:
                    self.user32.ShowWindow(hwnd, 5)  # SW_SHOW

                # 2. Attach thread input to bypass Windows focus-stealing restrictions
                cur_thread = self.kernel32.GetCurrentThreadId()
                fg_hwnd = self.user32.GetForegroundWindow()
                fg_thread = self.user32.GetWindowThreadProcessId(fg_hwnd, None) if fg_hwnd else 0
                target_thread = self.user32.GetWindowThreadProcessId(hwnd, None)

                if fg_thread and fg_thread != cur_thread:
                    self.user32.AttachThreadInput(cur_thread, fg_thread, True)
                if target_thread and target_thread != cur_thread:
                    self.user32.AttachThreadInput(cur_thread, target_thread, True)
                if fg_thread and target_thread and fg_thread != target_thread:
                    self.user32.AttachThreadInput(fg_thread, target_thread, True)

                try:
                    self.user32.AllowSetForegroundWindow(-1)  # ASFW_ANY = -1
                except Exception:
                    pass

                # 3. Bring to top of Z-order, set foreground and focus
                self.user32.BringWindowToTop(hwnd)
                self.user32.SetForegroundWindow(hwnd)
                self.user32.SetFocus(hwnd)

                # SetWindowPos HWND_TOP (0), SWP_NOSIZE (1) | SWP_NOMOVE (2) | SWP_SHOWWINDOW (0x0040)
                self.user32.SetWindowPos(hwnd, 0, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)

                # 4. Detach thread input
                if fg_thread and fg_thread != cur_thread:
                    self.user32.AttachThreadInput(cur_thread, fg_thread, False)
                if target_thread and target_thread != cur_thread:
                    self.user32.AttachThreadInput(cur_thread, target_thread, False)
                if fg_thread and target_thread and fg_thread != target_thread:
                    self.user32.AttachThreadInput(fg_thread, target_thread, False)

                return True
            except Exception:
                return False

        elif PLATFORM == 'darwin':
            try:
                info = self.get_window_info(wid)
                if not info:
                    return False
                target_pid = info.get('pid')
                target_owner = info.get('owner')

                # 1. Native Cocoa NSRunningApplication activate (instantaneous, ignores focus-stealing limits)
                if target_pid and target_pid > 0:
                    self.ns_app_activate(target_pid)

                # 2. Non-blocking LaunchServices activation via 'open -a' (brings app forward cleanly without AppleEvents)
                if target_owner:
                    try:
                        subprocess.Popen(['open', '-a', target_owner], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    except Exception:
                        pass

                # 3. Native Accessibility (AXUIElement) window unminimize and raise
                # (Uses existing Accessibility permission, ZERO AppleScript, ZERO Automation TCC permission prompts)
                if target_pid and target_pid > 0:
                    self.ax_raise_windows(target_pid)

                return True
            except Exception:
                pass
        return False

_global_wake_manager = DisplayWakeManager()
_global_frame_capturer = NativeFrameCapturer()

# Ensure any orphaned caffeinate from prior runs or unexpected kills is cleaned up
if PLATFORM == 'darwin':
    try:
        subprocess.run(['pkill', '-f', 'caffeinate.*-d -u'], check=False, timeout=1.0)
    except Exception:
        pass

atexit.register(lambda: _global_wake_manager.release(force=True))


def make_ws_frame(payload, opcode=0x01):
    data = payload.encode('utf-8') if isinstance(payload, str) else payload
    length = len(data)
    if length < 126:
        header = struct.pack("!BB", 0x80 | opcode, length)
    elif length < 65536:
        header = struct.pack("!BBH", 0x80 | opcode, 126, length)
    else:
        header = struct.pack("!BBQ", 0x80 | opcode, 127, length)
    return header + data

async def read_ws_frame(reader):
    header = await reader.readexactly(2)
    b1, b2 = header[0], header[1]
    opcode = b1 & 0x0F
    is_masked = (b2 & 0x80) != 0
    payload_len = b2 & 0x7F

    if payload_len == 126:
        ext = await reader.readexactly(2)
        payload_len = struct.unpack("!H", ext)[0]
    elif payload_len == 127:
        ext = await reader.readexactly(8)
        payload_len = struct.unpack("!Q", ext)[0]

    mask = await reader.readexactly(4) if is_masked else None
    payload = await reader.readexactly(payload_len) if payload_len > 0 else b""

    if is_masked and mask:
        payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))

    return opcode, payload

async def handle_client(reader, writer):
    global latest_mouse_coord, latest_mouse_updated, current_x, current_y, _active_daemon_writer, _primary_interactive_writer
    peer = writer.get_extra_info('peername')
    client_ip = peer[0] if peer else 'unknown'

    session_token = f"client-{id(writer)}"
    capture_active = False
    capture_target_type = 'display'
    capture_target_id = 0
    capture_fps = 30
    capture_task = None

    try:
        # Read HTTP GET handshake header
        try:
            req_bytes = await reader.readuntil(b'\r\n\r\n')
        except (asyncio.IncompleteReadError, ConnectionResetError, BrokenPipeError):
            # Port probe (e.g. supervisor health check) or client disconnected before completing HTTP handshake
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass
            return

        req_text = req_bytes.decode('utf-8', errors='replace')
        lines = req_text.split('\r\n')
        req_line = lines[0]
        parts = req_line.split()
        path = parts[1] if len(parts) > 1 else '/'

        headers = {}
        for line in lines[1:]:
            if not line: break
            if ':' in line:
                k, v = line.split(':', 1)
                headers[k.strip().lower()] = v.strip()

        origin = headers.get('origin', '').strip().rstrip('/')
        ws_key = headers.get('sec-websocket-key')

        # ── Check 1: Origin Validation (CSWSH Prevention) ──
        if not ALLOW_ALL_ORIGINS:
            if not is_origin_allowed(origin):
                print(f"[🚨 SECURITY BLOCKED] Unauthorized Origin: '{origin}' from {client_ip}")
                writer.write(b"HTTP/1.1 403 Forbidden\r\nConnection: close\r\nContent-Type: text/plain\r\n\r\nForbidden Origin\r\n")
                await writer.drain()
                writer.close()
                return

        if not ws_key:
            writer.write(b"HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\nMissing Sec-WebSocket-Key\r\n")
            await writer.drain()
            writer.close()
            return

        # Send 101 Switching Protocols
        accept = base64.b64encode(hashlib.sha1((ws_key + WS_GUID).encode()).digest()).decode()
        handshake_resp = (
            "HTTP/1.1 101 Switching Protocols\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Accept: {accept}\r\n\r\n"
        ).encode('utf-8')
        writer.write(handshake_resp)
        await writer.drain()

        _connected_control_clients.add(writer)

        # Send connected confirmation frame immediately with fresh screen bounds and persistent host config
        ox, oy, sw, sh = get_screen_bounds(force=True)
        cfg = load_host_config()
        can_capture = True
        if PLATFORM == 'darwin' and hasattr(_global_frame_capturer.cg, 'CGPreflightScreenCaptureAccess'):
            can_capture = bool(_global_frame_capturer.cg.CGPreflightScreenCaptureAccess())
            if not can_capture and hasattr(_global_frame_capturer.cg, 'CGRequestScreenCaptureAccess'):
                can_capture = bool(_global_frame_capturer.cg.CGRequestScreenCaptureAccess())
        connected_payload = {
            't': 'connected',
            'screen': [sw, sh],
            'origin': [ox, oy],
            'daemon_active': (_active_daemon_writer is not None),
            'has_config': (cfg is not None),
            'screen_capture_allowed': can_capture
        }
        if cfg:
            connected_payload['config'] = cfg
        writer.write(make_ws_frame(json.dumps(connected_payload)))
        await writer.drain()

        print(f"[+] Verified browser session connected from {client_ip} (Origin: {origin}, Screen: {sw}x{sh} at ({ox},{oy}))")

        # ── Native On-Demand Frame Capture & Streaming Engine ──
        # If host screen is currently locked, wake display immediately on client connect
        if _global_frame_capturer.is_screen_locked():
            _global_wake_manager.wake(session_token)

        _last_activity_time = time.monotonic()
        _last_frame_crc = None
        _last_frame_send_time = 0.0
        _accumulated_scroll_y = 0.0
        _accumulated_scroll_x = 0.0

        async def stream_frames_loop():
            nonlocal capture_active, capture_target_type, capture_target_id, capture_fps
            nonlocal _last_activity_time, _last_frame_crc, _last_frame_send_time
            active_delay = 1.0 / max(1, min(60, capture_fps))
            idle_delay = 0.2  # Maintain at least 5 FPS heartbeat to prevent WebRTC congestion control starvation
            stream_start_time = time.monotonic()
            _last_wake_pulse = 0.0
            while capture_active:
                t0 = time.time()
                now_mono = time.monotonic()
                is_idle = (now_mono - _last_activity_time) > 2.0
                is_startup = (now_mono - stream_start_time) < 4.0
                is_dirty = True

                try:
                    is_locked = _global_frame_capturer.is_screen_locked(max_age=1.5)
                    # While macOS is locked, ALWAYS capture physical display so login/lock screen is visible
                    if is_locked or capture_target_type != 'window' or capture_target_id <= 0:
                        jpeg_bytes, w, h = _global_frame_capturer.capture_display(capture_target_id if not is_locked else 0)
                        t_code = 1
                    else:
                        jpeg_bytes, w, h = _global_frame_capturer.capture_window(capture_target_id)
                        t_code = 2

                    if not jpeg_bytes or len(jpeg_bytes) == 0:
                        # Display is likely asleep or blank under DPMS; re-pulse wake periodically
                        if (now_mono - _last_wake_pulse) >= 2.0:
                            _last_wake_pulse = now_mono
                            print("[Power] Empty display capture detected (display may be asleep); pulsing display wake...")
                            _global_wake_manager.pulse_wake()
                        await asyncio.sleep(0.1)
                        continue

                    if jpeg_bytes and len(jpeg_bytes) > 0:
                        # Instant bounds sync fallback: if frame dimensions changed mid-stream, refresh cached bounds
                        if w > 0 and h > 0 and capture_target_type == 'display':
                            cur_b = _cached_bounds
                            if cur_b and (int(w) != cur_b[2] or int(h) != cur_b[3]):
                                get_screen_bounds(capture_target_id, force=True)
                                if _cached_bounds:
                                    ox_s, oy_s, sw_s, sh_s = _cached_bounds
                                    try:
                                        writer.write(make_ws_frame(json.dumps({'t': 'screen_bounds', 'w': sw_s, 'h': sh_s, 'ox': ox_s, 'oy': oy_s})))
                                    except Exception:
                                        pass
                        frame_crc = zlib.crc32(jpeg_bytes)
                        is_dirty = (frame_crc != _last_frame_crc)
                        if is_dirty:
                            _last_activity_time = now_mono
                            _last_frame_crc = frame_crc

                        # Send if frame is dirty, or during initial stream burst, or user recently interacted, or 0.2s elapsed since last frame
                        should_send = is_dirty or is_startup or (now_mono - _last_activity_time < 2.0) or (now_mono - _last_frame_send_time >= 0.2)
                        if should_send:
                            header = struct.pack('!BBIII', 1, t_code, int(capture_target_id or 0), int(w), int(h))
                            writer.write(make_ws_frame(header + jpeg_bytes, opcode=0x02))
                            await writer.drain()
                            _last_frame_send_time = now_mono
                except (asyncio.CancelledError, ConnectionResetError, BrokenPipeError):
                    break
                except Exception:
                    pass

                elapsed = time.time() - t0
                target_delay = idle_delay if (is_idle and not is_dirty and not is_startup) else active_delay
                sleep_time = max(0.005, target_delay - elapsed)
                await asyncio.sleep(sleep_time)

        # ── Process incoming WebRTC input events ──
        _cached_win_bounds = None
        _cached_win_time = 0.0
        _cached_win_target_id = None
        _last_win_activate_time = 0.0

        def ensure_window_active(win_id):
            nonlocal _last_win_activate_time
            now = time.monotonic()
            if (now - _last_win_activate_time) > 2.0:
                _last_win_activate_time = now
                _global_frame_capturer.activate_window(win_id)

        def map_client_coords(nx, ny):
            nonlocal _cached_win_bounds, _cached_win_time, _cached_win_target_id
            is_locked = _global_frame_capturer.is_screen_locked()
            win_id = int(capture_target_id or 0)
            if not is_locked and capture_target_type == 'window' and win_id > 0:
                now = time.monotonic()
                # Query window geometry at most once per second or immediately if target changed / bounds not yet cached
                if _cached_win_target_id != win_id or _cached_win_bounds is None or (now - _cached_win_time > 1.0):
                    _cached_win_time = now
                    _cached_win_target_id = win_id
                    b = _global_frame_capturer.get_window_bounds(win_id)
                    if b:
                        _cached_win_bounds = b
                if _cached_win_bounds:
                    wx, wy, ww, wh = _cached_win_bounds
                    tx = max(wx, min(wx + ww - 1, int(wx + nx * ww)))
                    ty = max(wy, min(wy + wh - 1, int(wy + ny * wh)))
                    return tx, ty

            ox, oy, sw, sh = get_screen_bounds(capture_target_id if (capture_target_type == 'display' and not is_locked) else None)
            tx = max(ox, min(ox + sw - 1, int(ox + nx * sw)))
            ty = max(oy, min(oy + sh - 1, int(oy + ny * sh)))
            return tx, ty

        # Ensure no stuck modifier keys from previous sessions or OS interrupts
        release_all_modifiers()

        while True:
            opcode, payload = await read_ws_frame(reader)
            if opcode == 0x08:  # Close frame
                writer.write(make_ws_frame(b'', opcode=0x08))
                await writer.drain()
                break
            elif opcode == 0x09:  # Ping
                writer.write(make_ws_frame(payload, opcode=0x0A))
                await writer.drain()
                continue
            elif opcode == 0x0A:  # Pong
                continue
            elif opcode != 0x01:  # Only process text
                continue

            text = payload.decode('utf-8', errors='replace')
            data = json.loads(text)
            evt_type = data.get('t') or data.get('action')

            if evt_type in ('mouse_move', 'mouse_down', 'mouse_up', 'mouse_click', 'wheel', 'key_down', 'key_up', 'special_key', 'type_text'):
                _last_activity_time = time.monotonic()
                _global_wake_manager.tickle(session_token)

            is_win = (capture_target_type == 'window' and int(capture_target_id or 0) > 0)
            win_pid = _global_frame_capturer.get_window_pid(capture_target_id) if is_win else None

            if evt_type == 'mouse_move':
                nx = float(data.get('x', 0))
                ny = float(data.get('y', 0))
                target_x, target_y = map_client_coords(nx, ny)
                latest_mouse_coord = (target_x, target_y, capture_target_id, is_win)
                latest_mouse_updated = True

            elif evt_type == 'mouse_down':
                btn = int(data.get('btn', 0))
                if is_win:
                    ensure_window_active(capture_target_id)
                if 'x' in data and 'y' in data:
                    nx = float(data.get('x', 0))
                    ny = float(data.get('y', 0))
                    target_x, target_y = map_client_coords(nx, ny)
                    execute_mouse_move(target_x, target_y, capture_target_id, is_win)
                native_mouse_down(btn, current_x, current_y, win_pid)

            elif evt_type == 'mouse_up':
                btn = int(data.get('btn', 0))
                if 'x' in data and 'y' in data:
                    nx = float(data.get('x', 0))
                    ny = float(data.get('y', 0))
                    target_x, target_y = map_client_coords(nx, ny)
                    execute_mouse_move(target_x, target_y, capture_target_id, is_win)
                native_mouse_up(btn, current_x, current_y, win_pid)

            elif evt_type in ('mouse_click', 'click'):
                btn = int(data.get('btn', 0))
                clicks = 2 if data.get('dbl') else 1
                if is_win:
                    ensure_window_active(capture_target_id)
                if 'x' in data and 'y' in data:
                    nx = float(data.get('x', 0))
                    ny = float(data.get('y', 0))
                    target_x, target_y = map_client_coords(nx, ny)
                    execute_mouse_move(target_x, target_y, capture_target_id, is_win)
                native_mouse_click(btn, clicks, current_x, current_y, win_pid)

            elif evt_type in ('select_display', 'switch_display'):
                selected_display_id = data.get('id') if data.get('id') is not None else data.get('displayId')
                _cached_win_bounds = None
                _cached_win_target_id = None
                ox, oy, sw, sh = get_screen_bounds(selected_display_id, force=True)
                writer.write(make_ws_frame(json.dumps({'t': 'screen_bounds', 'w': sw, 'h': sh, 'ox': ox, 'oy': oy})))
                await writer.drain()

            elif evt_type == 'wheel':
                if 'x' in data and 'y' in data:
                    nx = float(data.get('x', 0))
                    ny = float(data.get('y', 0))
                    target_x, target_y = map_client_coords(nx, ny)
                    execute_mouse_move(target_x, target_y, capture_target_id, is_win)
                dy = float(data.get('dy', 0))
                dx = float(data.get('dx', 0))
                _accumulated_scroll_y += dy
                _accumulated_scroll_x += dx

                # Smooth fractional wheel accumulator (prevents small mobile touchmoves from truncating to 0)
                SCROLL_THRESHOLD = 8.0
                if abs(_accumulated_scroll_y) >= SCROLL_THRESHOLD:
                    units_y = -int(_accumulated_scroll_y / SCROLL_THRESHOLD)
                    _accumulated_scroll_y += units_y * SCROLL_THRESHOLD
                    if units_y != 0:
                        native_scroll(units_y, win_pid)

            elif evt_type == 'key_down':
                raw_key = data.get('key', '')
                mods = {
                    'shift': bool(data.get('shift', False)),
                    'ctrl': bool(data.get('ctrl', False)),
                    'alt': bool(data.get('alt', False)),
                    'meta': bool(data.get('meta', False))
                }
                if is_win:
                    ensure_window_active(capture_target_id)
                if raw_key: native_key(raw_key, True, mods, win_pid)

            elif evt_type == 'key_up':
                raw_key = data.get('key', '')
                mods = {
                    'shift': bool(data.get('shift', False)),
                    'ctrl': bool(data.get('ctrl', False)),
                    'alt': bool(data.get('alt', False)),
                    'meta': bool(data.get('meta', False))
                }
                if raw_key: native_key(raw_key, False, mods, win_pid)

            elif evt_type == 'special_key':
                if is_win:
                    ensure_window_active(capture_target_id)
                action = data.get('key')
                if action == 'win':
                    native_key('command' if PLATFORM == 'darwin' else 'win', True, target_pid=win_pid)
                    native_key('command' if PLATFORM == 'darwin' else 'win', False, target_pid=win_pid)
                elif action == 'esc':
                    native_key('escape', True, target_pid=win_pid)
                    native_key('escape', False, target_pid=win_pid)
                elif action == 'enter':
                    native_key('return', True, target_pid=win_pid)
                    native_key('return', False, target_pid=win_pid)
                elif action == 'capslock':
                    native_key('capslock', True, target_pid=win_pid)
                    native_key('capslock', False, target_pid=win_pid)

            elif evt_type == 'type_text':
                if is_win:
                    ensure_window_active(capture_target_id)
                t_str = data.get('text', '')
                if t_str: native_type_text(t_str, win_pid)

            elif evt_type == 'clipboard':
                clip_text = data.get('text', '')
                if clip_text:
                    native_set_clipboard(clip_text)
                    writer.write(make_ws_frame(json.dumps({'t': 'clipboard_ack', 'status': 'ok'})))
                    await writer.drain()

            elif evt_type == 'get_clipboard':
                curr_clip = native_get_clipboard()
                writer.write(make_ws_frame(json.dumps({'t': 'clipboard', 'text': curr_clip})))
                await writer.drain()

            elif evt_type == 'ping_diag':
                can_cap = bool(cg.CGPreflightScreenCaptureAccess()) if 'cg' in globals() and hasattr(cg, 'CGPreflightScreenCaptureAccess') else None
                diag = {
                    't': 'pong_diag',
                    'pid': os.getpid(),
                    'can_capture': can_cap,
                    'is_locked': _global_frame_capturer.is_screen_locked(),
                    'targets': _global_frame_capturer.enumerate_targets()
                }
                writer.write(make_ws_frame(json.dumps(diag)))
                await writer.drain()

            elif evt_type == 'open_screen_recording_settings':
                if PLATFORM == 'darwin':
                    try:
                        subprocess.Popen(['open', 'x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture'])
                    except Exception:
                        pass

            elif evt_type in ('start_capture', 'action') or data.get('action') == 'start_capture':
                capture_target_type = data.get('target', 'display')
                capture_target_id = int(data.get('id', 0))
                capture_fps = int(data.get('fps', 30))
                _cached_win_bounds = None
                _cached_win_time = 0.0
                _cached_win_target_id = None
                if capture_target_type == 'window' and capture_target_id > 0:
                    _global_frame_capturer.activate_window(capture_target_id)
                _global_wake_manager.wake(session_token)
                capture_active = True
                if capture_task and not capture_task.done():
                    capture_task.cancel()
                capture_task = asyncio.create_task(stream_frames_loop())
                print(f"[+] Started native capture: target={capture_target_type}, id={capture_target_id}, fps={capture_fps}")
                writer.write(make_ws_frame(json.dumps({'t': 'capture_started', 'target': capture_target_type, 'id': capture_target_id})))
                await writer.drain()

            elif evt_type in ('wake_display', 'wake_screen'):
                _global_wake_manager.wake(session_token)
                _global_wake_manager.pulse_wake()
                print("[Power] wake_display command received from host client; pulsed display wake")
                writer.write(make_ws_frame(json.dumps({'t': 'display_woken'})))
                await writer.drain()

            elif evt_type in ('stop_capture', 'action') or data.get('action') == 'stop_capture':
                capture_active = False
                _cached_win_bounds = None
                _cached_win_target_id = None
                if capture_task and not capture_task.done():
                    capture_task.cancel()
                    capture_task = None
                _global_wake_manager.release(session_token)
                print("[+] Stopped native capture")
                if data.get('auto_lock'):
                    print("[Power] auto_lock requested on stop_capture")
                    lock_host_screen()
                writer.write(make_ws_frame(json.dumps({'t': 'capture_stopped'})))
                await writer.drain()

            elif evt_type in ('get_targets', 'get_monitors'):
                targets = _global_frame_capturer.enumerate_targets()
                writer.write(make_ws_frame(json.dumps({
                    't': 'targets',
                    'displays': targets['displays'],
                    'windows': targets['windows'],
                    'monitors': targets['displays']  # backward compatibility
                })))
                await writer.drain()

            elif evt_type == 'select_target':
                capture_target_type = data.get('target', 'display')
                capture_target_id = int(data.get('id', 0))
                _cached_win_bounds = None
                _cached_win_time = 0.0
                _cached_win_target_id = None
                if capture_target_type == 'window' and capture_target_id > 0:
                    _global_frame_capturer.activate_window(capture_target_id)
                if capture_target_type == 'display':
                    selected_display_id = capture_target_id
                    ox, oy, sw, sh = get_screen_bounds(capture_target_id, force=True)
                    try:
                        writer.write(make_ws_frame(json.dumps({'t': 'screen_bounds', 'w': sw, 'h': sh, 'ox': ox, 'oy': oy})))
                    except Exception:
                        pass
                if not capture_active:
                    _global_wake_manager.wake(session_token)
                    capture_active = True
                    capture_task = asyncio.create_task(stream_frames_loop())
                    print(f"[+] Auto-started capture loop on select_target: {capture_target_type}:{capture_target_id}")
                else:
                    print(f"[+] Switched capture target to: {capture_target_type}:{capture_target_id}")
                writer.write(make_ws_frame(json.dumps({'t': 'target_selected', 'target': capture_target_type, 'id': capture_target_id})))
                await writer.drain()

            elif evt_type == 'ping':
                writer.write(make_ws_frame(json.dumps({'t': 'pong'})))
                await writer.drain()

            elif evt_type == 'lock_screen':
                print("[Power] Received remote screen lock request")
                lock_host_screen()

            elif evt_type == 'register_daemon':
                _active_daemon_writer = writer
                print(f"[+] Headless Host Daemon registered with bridge ({client_ip})")
                status_msg = make_ws_frame(json.dumps({'t': 'daemon_status', 'daemon_active': True}))
                for client in list(_connected_control_clients):
                    if client != writer:
                        try: client.write(status_msg)
                        except Exception: pass

            elif evt_type == 'claim_host_focus':
                _primary_interactive_writer = writer
                print(f"[+] Interactive browser tab claimed primary hosting focus ({client_ip})")
                if _active_daemon_writer and _active_daemon_writer != writer:
                    try: _active_daemon_writer.write(make_ws_frame(json.dumps({'t': 'daemon_standby'})))
                    except Exception: pass
                writer.write(make_ws_frame(json.dumps({'t': 'host_focus_claimed', 'primary': True})))
                await writer.drain()

            elif evt_type == 'release_host_focus':
                if _primary_interactive_writer == writer:
                    _primary_interactive_writer = None
                print(f"[-] Interactive browser tab released primary hosting focus ({client_ip})")
                if _active_daemon_writer:
                    try: _active_daemon_writer.write(make_ws_frame(json.dumps({'t': 'daemon_resume'})))
                    except Exception: pass
                writer.write(make_ws_frame(json.dumps({'t': 'host_focus_released'})))
                await writer.drain()

            elif evt_type == 'save_host_config':
                new_cfg = data.get('config', {})
                if new_cfg and isinstance(new_cfg, dict):
                    save_host_config(new_cfg)
                    print(f"[+] Saved persistent host config (pubkey: {new_cfg.get('host_pubkey', '')[:16]}...)")
                    cfg_msg = make_ws_frame(json.dumps({'t': 'host_config_updated', 'config': _cached_host_config}))
                    for client in list(_connected_control_clients):
                        try: client.write(cfg_msg)
                        except Exception: pass

    except (asyncio.IncompleteReadError, ConnectionResetError, BrokenPipeError):
        print(f"[-] Browser disconnected ({client_ip})")
    except Exception as err:
        print(f"[!] Error: {err}")
    finally:
        if writer in _connected_control_clients:
            _connected_control_clients.remove(writer)
        if _primary_interactive_writer == writer:
            _primary_interactive_writer = None
            print(f"[-] Interactive browser tab disconnected, released primary focus ({client_ip})")
            if _active_daemon_writer:
                try: _active_daemon_writer.write(make_ws_frame(json.dumps({'t': 'daemon_resume'})))
                except Exception: pass
        if _active_daemon_writer == writer:
            _active_daemon_writer = None
            print("[-] Headless Host Daemon unregistered from bridge")
            status_msg = make_ws_frame(json.dumps({'t': 'daemon_status', 'daemon_active': False}))
            for client in list(_connected_control_clients):
                try: client.write(status_msg)
                except Exception: pass
        if capture_active:
            capture_active = False
        if capture_task and not capture_task.done():
            capture_task.cancel()
        release_all_modifiers()
        _global_wake_manager.release(session_token)
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass

async def main(host, port, token, extra_origins, allow_all, bounds_ttl=None):
    global ACTIVE_AUTH_TOKEN, ACTIVE_ALLOWED_ORIGINS, ALLOW_ALL_ORIGINS, BOUNDS_CACHE_TTL

    if bounds_ttl is not None:
        BOUNDS_CACHE_TTL = float(bounds_ttl)

    ACTIVE_AUTH_TOKEN = load_or_create_token(token)
    ACTIVE_ALLOWED_ORIGINS = set(DEFAULT_ALLOWED_ORIGINS)
    if extra_origins:
        for orig in extra_origins:
            ACTIVE_ALLOWED_ORIGINS.add(orig.strip().rstrip('/'))
    ALLOW_ALL_ORIGINS = allow_all

    dir_path = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(dir_path)
    cert_file = os.path.join(dir_path, "cert.pem") if os.path.exists(os.path.join(dir_path, "cert.pem")) else os.path.join(project_root, "cert.pem")
    key_file = os.path.join(dir_path, "key.pem") if os.path.exists(os.path.join(dir_path, "key.pem")) else os.path.join(project_root, "key.pem")

    ssl_ctx = None
    if os.path.exists(cert_file) and os.path.exists(key_file):
        try:
            ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ssl_ctx.load_cert_chain(cert_file, key_file)
        except Exception:
            ssl_ctx = None

    print("=" * 68)
    print("  🔒 P2P Connect — Zero-Dependency Native OS Host Bridge")
    print("=" * 68)
    print(f"  Plain WS:  ws://{host}:{port}")
    if ssl_ctx:
        print(f"  Secure WSS: wss://{host}:9998 (TLS with cert.pem)")
    print(f"  Screen Resolution: {SCREEN_WIDTH} x {SCREEN_HEIGHT}")
    print(f"  Bounds Cache TTL:  {BOUNDS_CACHE_TTL:.0f}s (on connection & 5m background check)")
    print(f"  Platform: {PLATFORM} (Native CoreGraphics / Win32 acceleration)")
    print("  Security Hardening Status:")
    if ALLOW_ALL_ORIGINS:
        print("    ⚠️  Origin Check: DISABLED (Warning: vulnerable to CSWSH)")
    else:
        print(f"    ✓ Origin Filtering: ENFORCED (allowed domains & LAN IPs)")
    print("    ✓ Emergency Stop: Available via Host UI & Disconnect button")
    print("    ✓ On-Demand Capture: READY (Display & Window hardware capture)")
    print("    ✓ Display Wake on Demand: ENABLED (Screen sleeps naturally when idle)")

    if PLATFORM == 'darwin':
        can_cap = True
        if hasattr(_global_frame_capturer.cg, 'CGPreflightScreenCaptureAccess'):
            can_cap = bool(_global_frame_capturer.cg.CGPreflightScreenCaptureAccess())
            if not can_cap and hasattr(_global_frame_capturer.cg, 'CGRequestScreenCaptureAccess'):
                can_cap = bool(_global_frame_capturer.cg.CGRequestScreenCaptureAccess())
        if can_cap:
            print("    ✓ macOS Screen Recording: GRANTED")
        else:
            print("    ❌ macOS Screen Recording: DENIED (Will capture black screen #202020!)")
            print("       -> Open System Settings > Privacy & Security > Screen & System Audio Recording")
            print("       -> Enable 'Terminal' (and/or 'Python'), then Quit & Reopen Terminal.")
    print("=" * 68)
    print("Ready! Waiting for authenticated browser remote control session...\n")

    # Start non-blocking cursor worker
    asyncio.create_task(mouse_worker())

    srv_ws = await asyncio.start_server(handle_client, host, port)
    tasks = [srv_ws.serve_forever()]

    if ssl_ctx:
        try:
            srv_wss = await asyncio.start_server(handle_client, host, 9998, ssl=ssl_ctx)
            tasks.append(srv_wss.serve_forever())
        except Exception as e:
            print(f"[!] Warning: Could not bind secure WSS on port 9998: {e}")

    await asyncio.gather(*tasks)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="P2P Connect Zero-Dependency Remote Desktop Bridge")
    parser.add_argument("--host", default="0.0.0.0", help="Binding host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=9999, help="Binding port (default: 9999)")
    parser.add_argument("--token", default=None, help="Custom authorization token secret")
    parser.add_argument("--allow-origin", action="append", default=[], help="Additional allowed Origin URL")
    parser.add_argument("--allow-all-origins", action="store_true", help="Disable Origin checking")
    parser.add_argument("--bounds-ttl", type=float, default=DEFAULT_BOUNDS_CACHE_TTL, help="Screen bounds cache TTL in seconds (default: 300.0 / 5 min)")
    args = parser.parse_args()

    try:
        asyncio.run(main(args.host, args.port, args.token, args.allow_origin, args.allow_all_origins, args.bounds_ttl))
    except KeyboardInterrupt:
        print("\n[+] Host bridge stopped.")
